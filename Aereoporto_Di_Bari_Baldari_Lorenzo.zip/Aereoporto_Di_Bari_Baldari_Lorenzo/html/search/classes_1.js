var searchData=
[
  ['date',['date',['../structdate.html',1,'']]]
];
