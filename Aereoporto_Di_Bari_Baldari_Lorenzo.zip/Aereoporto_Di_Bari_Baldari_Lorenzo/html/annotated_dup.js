var annotated_dup =
[
    [ "bookings", "structbookings.html", null ],
    [ "date", "structdate.html", null ],
    [ "flights", "structflights.html", null ],
    [ "passengers", "structpassengers.html", null ],
    [ "time", "structtime.html", null ]
];