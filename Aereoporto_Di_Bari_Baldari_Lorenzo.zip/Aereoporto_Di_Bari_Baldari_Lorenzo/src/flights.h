#ifndef FLIGHTS_H_
#define FLIGHTS_H_

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 * Max lenght for strings
 */
#define LEN 20

/**
 * Structure defined to
 * insert a time, expressed
 * in hours and minutes.
 */
typedef struct time {
	int hours, minutes;
} time;

/**
 * Structure defined to contain
 * all the fields required
 * to identify a flight.
 */
typedef struct flights {
	char id[LEN], company[LEN], departure[LEN], arrival[LEN], vehicle[LEN];

	int seats;

	date date;

	time estimated_departure;

	time duration;

} flights;

/**
 * See utility.h doc.
 */
void flagMessage(int x);	//output message based on int value
int rowCount(FILE *input, char *file_name);	//count rows in a file
int flagChecker(int x, int y);	//check flag: flag AND flag

/**
 *
 * This function start loading flights data
 * from flights.csv into flights array.
 *
 * @param input Pointer to file flights.csv
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsLoad(FILE *input, flights array[], int x);//load flights into array

/**
 *
 * This function start printing flights data
 * into flights.csv from flights array.
 *
 * @param input Pointer to file flights.csv
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsPrinter(FILE *input, flights array[], int x);//print array to file

/**
 *
 * This function will request the admin the number of
 * flights to add. Every flight is added in a
 * temporary array, then data will be printed
 * in append mode into the flights.csv file.
 * When the function reaches the final stage, the
 * flag will be set to 1 in case of success.
 *
 * @param input Pointer to file flights.csv
 * @return
 */
int flightsAdd(FILE *input);		//add flights to array

/**
 *
 * This function start editing flights data
 * stored into flights array. It will request
 * the administrator the flight number to edit.
 * When the function reaches the final stage, new
 * informations about flights will be overwritten
 * in flights.csv file and the flag will be set to 1.
 *
 * @param input Pointer to file flights.csv
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsEditor(FILE *input, flights array[], int x);	//edit flights

/**
 *
 * This function will request the admin to select
 * the flight number. Then, to delete, it will start
 * moving the elements into array.
 * This will result in a reduction of the array dimension.
 * In case of success, flag will be set to 1.
 *
 * @param input	Pointer to file flights.csv
 * @param array	Flights array
 * @param x	Array dimension
 * @return
 */
int flightsDelete(FILE *input, flights array[], int x);	//delete flight

/**
 *
 * This function start print
 * all the flights data
 * contained into the array.
 * Flag will be set to 1 in case
 * of success.
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsView(flights array[], int x);	//output flights

/**
 *
 * This function will clone the flights array
 * into a temporary one to avoid data loss.
 * Flag will be set to 1 in case of success.
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @param temp	Temporary array
 * @return flag 1 if success, 0 else
 */
int flightsCloner(flights array[], int x, flights temp[]);	//clone array

/**
 *
 * This function will start a new
 * flight search by company, which will
 * be requested to prompt.
 * Flag will be set to 1 in case of success.
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsSearch_Company(flights array[], int x);	//search by company

/**
 *
 * This function will start a new
 * flight search by departure, which will be
 * requested to prompt.
 * Flag will be set to 1 in case of success.
 *
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsSearch_Departure(flights array[], int x);	//search by departure

/**
 *
 * This function will start a new
 * flight search by arrival, which will
 * be requested to prompt.
 * Flag will be set to 1 in case of success.
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsSearch_Arrival(flights array[], int x);	//search by arrival

/**
 *
 * This function will start a new
 * flight search by vehicle.
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsSearch_Vehicle(flights array[], int x);	//search by vehicle

/**
 *
 * This function will show a menu in
 * which the administrator can select search
 * option.
 * Flag will be set to 1 in case of success.
 *
 * @param array	Flights array
 * @param x	Array dimension
 * @return	flag 1 if success, 0 else
 */
int flightsSearch(flights array[], int x);	//search menu

/**
 *
 * This function will increase sort flights
 * by month.
 * Flag will be set to 1 in case of success.
 *
 * @param test	Flights array
 * @param x	Array dimension
 * @return flag 1 if success, 0 else
 */
int flightsIncreasingBubbleSort_Month(flights test[], int x);	//bubble sorts

/**
 *
 * This function will decrease sort flights
 * by month.
 * Flag will be set to 1 in case of success.
 * @param test	Flights array
 * @param x	Array dimension
 * @return flag 1 if success, 0 else
 */
int flightsDecreasingBubbleSort_Month(flights test[], int x);	//

/**
 *
 * This function will increase sort flights
 * by seats.
 * Flag will be set to 1 in case of success.
 *
 * @param test	Flights array
 * @param x	Array dimension
 * @return flag 1 if success, 0 else
 */
int flightsIncreasingBubbleSort_Seats(flights test[], int x);	//

/**
 *
 * This function will decrease sort flights
 * by seats.
 * Flag will be set to 1 in case of success.
 *
 * @param test	Flights array
 * @param x	Array dimension
 * @return flag 1 if success, 0 else
 */
int flightsDecreasingBubbleSort_Seats(flights test[], int x);	//

/**
 * This method will show the admin a menu
 * in which are listed sorting options
 * for flights.
 */
void flightsSortingMenu(void);	//sorting menu

/**
 * This method will show the admin a menu
 * in which are listed administration options
 * to manage flights.
 */
void flightsMenu_AdministratorOnly(void);	//administrator menu

#endif /* FLIGHTS_H_ */
