#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

#define LEN 20
#define MIN_LEN 3
#define MAX_LEN 19

/**
 * Structure defined to
 * insert a time, expressed
 * in hours and minutes.
 */
typedef struct time {
	int hours, minutes;
} time;

/**
 * Structure defined to contain
 * data structured as dates.
 */
typedef struct date {

	int day, month, year;

} date;

/**
 * Structure defined to contain
 * all the fields required
 * to identify a flight.
 */
typedef struct flights {
	char id[LEN], company[LEN], departure[LEN], arrival[LEN], vehicle[LEN];

	int seats;

	date date;

	time estimated_departure;

	time duration;

} flights;

/**
 * Pre-conditions:
 * 	File must exists.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsLoad(FILE *input, flights array[], int x) {
	int flag = 0;		//this will be the return value

	for (int i = 0; i < x; i++) {			//fscanf file's row into array
		fscanf(input, "%[^,],%[^,],%[^,],%[^,],%[^,],%d,%d,%d,%d,%d,%d,%d,%d\n",
				array[i].id, array[i].company, array[i].departure,
				array[i].arrival, array[i].vehicle, &array[i].seats,
				&array[i].date.day, &array[i].date.month, &array[i].date.year,
				&array[i].estimated_departure.hours,
				&array[i].estimated_departure.minutes, &array[i].duration.hours,
				&array[i].duration.minutes);
		flag = 1;		//set flag to 1 if success
	}
	rewind(input);		//rewind stream
	fclose(input);		//close file
	return flag;		//0 if fail, 1 if success
}

/**
 * Pre-conditions:
 * 	File must exists.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsPrinter(FILE *input, flights array[], int x) {
	int flag = 0;

	for (int i = 0; i < x; i++) {		//print data into file
		fprintf(input, "%s,%s,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d\n", array[i].id,
				array[i].company, array[i].departure, array[i].arrival,
				array[i].vehicle, array[i].seats, array[i].date.day,
				array[i].date.month, array[i].date.year,
				array[i].estimated_departure.hours,
				array[i].estimated_departure.minutes, array[i].duration.hours,
				array[i].duration.minutes);
		flag = 1;		//set flag to 1 if success, 0 if fail
	}
	rewind(input);		//rewind stream
	fclose(input);		//close file
	return flag;		//return flag
}

/**
 * Pre-conditions:
 * 	File must exists.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsAdd(FILE *input) {

	int x = 0, flag = 0, flag2 = 0, flag3 = 0;

	system("clear");
	printf("\nHow many flights do you want to add? ");
	scanf("%d", &x);		//get flights number

	if (x > 0) {
		flights array[x];		//create n-array flights

		input = fopen("flights.csv", "a");//open file flights.csv in append mode

		if ((input = fopen("flights.csv", "a")) == NULL) {//check over file open
			system("clear");
			printf("\nFile not found.\n"
					"I'll create one."
					"\nPress ENTER key to continue.");
			getchar();
			getchar();
		} else {
			for (int i = 0; i < x; i++) {
				system("clear");

				printf("\n%d° fly.\n", i);

				printf("\nInsert fly ID: ");	//get fly id
				scanf("%s", array[i].id);
				while ((strlen(array[i].id) < MIN_LEN)
						|| (strlen(array[i].id) > MAX_LEN)) {//check if id is valid
					printf("\nInvalid ID."
							"Please, insert a valid ID (min 3 chars.): ");
					scanf("%s", array[i].id);
				}

				printf("\nInsert company: ");
				scanf("%s", array[i].company);
				while ((strlen(array[i].company) < MIN_LEN)
						|| (strlen(array[i].company) > MAX_LEN)) {
					printf("\nInvalid company.\n"
							"Please, insert a valid company (min 1 char.): ");
					scanf("%s", array[i].company);
				}

				printf("\nInsert departure: ");
				scanf("%s", array[i].departure);
				while ((strlen(array[i].departure) < MIN_LEN)
						|| (strlen(array[i].departure) > MAX_LEN)) {
					printf("\nInvalid departure.\n"
							"Please, insert a valid departure (min 3 chars): ");
					scanf("%s", array[i].departure);
				}

				printf("\nInsert arrival: ");
				scanf("%s", array[i].arrival);
				while ((strlen(array[i].arrival) < MIN_LEN)
						|| (strlen(array[i].arrival) > MAX_LEN)) {
					printf("\nInvalid arrival.\n"
							"Please, enter a valid arrival (min 3 chars.): ");
					scanf("%s", array[i].arrival);
				}

				printf("\nInsert the vehicle: ");
				scanf("%s", array[i].vehicle);
				while ((strlen(array[i].vehicle) < MIN_LEN)
						|| (strlen(array[i].vehicle) > MAX_LEN)) {
					printf("\nInvalid vehicle.\n"
							"Please, insert a valid vehicle (min 3 chars.): ");
					scanf("%s", array[i].vehicle);
				}

				printf("\nInsert the max number of available seats: ");
				scanf("%d", &array[i].seats);
				while (array[i].seats <= 0) {
					printf("\nInvalid number.\n"
							"Please, insert a valid one (>0): ");
					scanf("%d", &array[i].seats);
				}

				/**
				 * 	DAY *
				 **/
				printf("\nInsert the fly day: ");	//get b.day
				scanf("%d", &array[i].date.day);

				if (array[i].date.day < 1 || array[i].date.day > 31) {//day check
					while (array[i].date.day == 0 || array[i].date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid fly day: ");
						scanf("%d", &array[i].date.day);
					}
				}

				printf("\nInsert the fly month: ");	//get birth month
				scanf("%d", &array[i].date.month);

				if (array[i].date.month == 0 || array[i].date.month > 12) {	//check month
					while (array[i].date.month == 0 || array[i].date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a valid fly month: ");
						scanf("%d", &array[i].date.month);
					}
				}

				if (array[i].date.day > 28) {	//check february
					while (array[i].date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid fly month: ");
						scanf("%d", &array[i].date.month);
					}
				}

				if (array[i].date.day == 31) {	//check month
					while (array[i].date.month == 4 || array[i].date.month == 6
							|| array[i].date.month == 9
							|| array[i].date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid birth month: ");
						scanf("%d", &array[i].date.month);
					}
				}

				printf("\nInsert fly year: ");		//get birth year
				scanf("%d", &array[i].date.year);
				if (array[i].date.year < 1920 || array[i].date.year > 2019) {
					printf("\nInvalid year.\n"
							"Please, insert a valid fly year: ");
					scanf("%d", &array[i].date.year);
				}

				/**
				 * ESTIMATED
				 * 	DEPARTURE
				 */

				printf("\nInsert estimated departure hour (24h): ");
				scanf("%d", &array[i].estimated_departure.hours);
				while (array[i].estimated_departure.hours > 24) {
					printf("\nInvalid hour.\n"
							"Please, insert a valid departure hour (24h): ");
					scanf("%d", &array[i].estimated_departure.hours);
				}

				printf("\nInsert estimated departure minutes: ");
				scanf("%d", &array[i].estimated_departure.minutes);
				while (array[i].estimated_departure.minutes > 59) {
					printf("\nInvalid minutes.\n"
							"Please, insert a valid departure value (<60): ");
					scanf("%d", &array[i].estimated_departure.minutes);
				}

				/**
				 * ESTIMATED
				 * DURATION
				 */

				printf("\nInsert estimated duration in hours: ");
				scanf("%d", &array[i].duration.hours);
				while (array[i].duration.hours > 24) {
					printf("\nInvalid hour.\n"
							"Please, insert a valid one: ");
					scanf("%d", &array[i].duration.hours);
				}

				printf(
						"\nInsert estimated duration in minutes (00 if o' clock): ");
				scanf("%d", &array[i].duration.minutes);
				while (array[i].duration.minutes > 59) {
					printf("\nInvalid value.\n"
							"Please, insert a valid one: ");
					scanf("%d", &array[i].duration.minutes);
				}

			} //end acquisition for
		} //end else
		flag2 = 1;
		flag3 = flightsPrinter(input, array, x);
	}

	flag = flagChecker(flag2, flag3);
	return flag;
}

/**
 * Pre-conditions:
 * 	File must exists.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsEditor(FILE *input, flights array[], int x) {
	system("clear");

	char select = 'n';

	int edited = 0, flag = 0, flag2 = 0, flag3 = 0;

	printf("\nDo you want to edit a fly? [y/n]: ");
	getchar();
	scanf("%c", &select);

	if (select == 'y') {

		system("clear");

		printf("\nInsert the fly number to edit: ");
		scanf("%d", &edited);

		printf("\n%d° fly."
				"Press ENTER to start editing.", edited);
		getchar();
		getchar();

		printf("\nInsert fly ID: "); //get fly id
		scanf("%s", array[edited].id);
		while (strlen(array[edited].id) < 3) {	//check if id is valid
			printf("\nInvalid ID."
					"Please, insert a valid ID (min 3 chars.): ");
			scanf("%s", array[edited].id);
		}

		printf("\nInsert company: ");
		scanf("%s", array[edited].company);
		while (strlen(array[edited].company) < 1) {
			printf("\nInvalid company.\n"
					"Please, insert a valid company (min 1 char.): ");
			scanf("%s", array[edited].company);
		}

		printf("\nInsert departure: ");
		scanf("%s", array[edited].departure);
		while (strlen(array[edited].departure) < 3) {
			printf("\nInvalid departure.\n"
					"Please, insert a valid departure (min 3 chars): ");
			scanf("%s", array[edited].departure);
		}

		printf("\nInsert arrival: ");
		scanf("%s", array[edited].arrival);
		while (strlen(array[edited].arrival) < 3) {
			printf("\nInvalid arrival.\n"
					"Please, enter a valid arrival (min 3 chars.): ");
			scanf("%s", array[edited].arrival);
		}

		printf("\nInsert the vehicle: ");
		scanf("%s", array[edited].vehicle);
		while (strlen(array[edited].vehicle) < 3) {
			printf("\nInvalid vehicle.\n"
					"Please, insert a valid vehicle (min 3 chars.): ");
			scanf("%s", array[edited].vehicle);
		}

		printf("\nInsert the max number of available seats: ");
		scanf("%d", &array[edited].seats);
		while (array[edited].seats <= 0) {
			printf("\nInvalid number.\n"
					"Please, insert a valid one (>0): ");
			scanf("%d", &array[edited].seats);
		}

		/**
		 * 	DAY *
		 **/
		printf("\nInsert the fly day: ");	//get b.day
		scanf("%d", &array[edited].date.day);

		if (array[edited].date.day < 1 || array[edited].date.day > 31) {//day check
			while (array[edited].date.day == 0 || array[edited].date.day > 31) {
				printf("\nInvalid day.\n"
						"Please, insert a valid fly day: ");
				scanf("%d", &array[edited].date.day);
			}
		}

		printf("\nInsert the fly month: ");	//get birth month
		scanf("%d", &array[edited].date.month);

		if (array[edited].date.month == 0 || array[edited].date.month > 12) {//check month
			while (array[edited].date.month == 0
					|| array[edited].date.month > 12) {
				printf("\nInvalid month."
						"\nPlease, insert a valid fly month: ");
				scanf("%d", &array[edited].date.month);
			}
		}

		if (array[edited].date.day > 28) {	//check february
			while (array[edited].date.month == 2) {
				printf("\nInvalid month."
						"\nPlease, Insert a valid fly month: ");
				scanf("%d", &array[edited].date.month);
			}
		}

		if (array[edited].date.day == 31) {	//check month
			while (array[edited].date.month == 4
					|| array[edited].date.month == 6
					|| array[edited].date.month == 9
					|| array[edited].date.month == 11) {
				printf("\nInvalid month."
						"\nPlease, insert a valid birth month: ");
				scanf("%d", &array[edited].date.month);
			}
		}

		printf("\nInsert fly year: ");		//get birth year
		scanf("%d", &array[edited].date.year);
		if (array[edited].date.year < 1920 || array[edited].date.year > 2019) {
			printf("\nInvalid year.\n"
					"Please, insert a valid fly year: ");
			scanf("%d", &array[edited].date.year);
		}

		/**
		 * ESTIMATED
		 * 	DEPARTURE
		 */

		printf("\nInsert estimated departure hour: ");
		scanf("%d", &array[edited].estimated_departure.hours);
		while (array[edited].estimated_departure.hours > 24) {
			printf("\nInvalid hour.\n"
					"Please, insert a valid departure hour: ");
			scanf("%d", &array[edited].estimated_departure.hours);
		}

		printf("\nInsert estimated minutes: ");
		scanf("%d", &array[edited].estimated_departure.minutes);
		while (array[edited].estimated_departure.minutes > 59) {
			printf("\nInvalid minutes.\n"
					"Please, insert a valid departure value (<60): ");
			scanf("%d", &array[edited].estimated_departure.minutes);
		}

		/**
		 * ESTIMATED
		 * DURATION
		 */

		printf("\nInsert estimated duration in hours: ");
		scanf("%d", &array[edited].duration.hours);
		while (array[edited].duration.hours > 24) {
			printf("\nInvalid hour.\n"
					"Please, insert a valid one: ");
			scanf("%d", &array[edited].duration.hours);
		}

		printf("\nInsert estimated duration in minutes (if any): ");
		scanf("%d", &array[edited].duration.minutes);
		while (array[edited].duration.minutes > 59) {
			printf("\nInvalid value.\n"
					"Please, insert a valid one: ");
			scanf("%d", &array[edited].duration.minutes);
		}
		flag2 = 1;
	}
	input = fopen("flights.csv", "w");

	if (flag2 == 1) {
		if ((input = fopen("flights.csv", "w")) == NULL) {
			printf("\nFile not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flag3 = flightsPrinter(input, array, x);
		}
	}

	flag = flagChecker(flag2, flag3);
	rewind(input);
	fclose(input);
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 * 	File must exists.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsDelete(FILE *input, flights array[], int x) {
	int deleted = 0, flag = 0, flag2 = 0, flag3 = 0;
	char select = 'y';

	system("clear");

	printf("\nDo you want to delete a fly? [y/n]: ");
	scanf("%c", &select);

	printf("\nInsert the fly number: ");
	scanf("%d", &deleted);

	for (int i = deleted; i < x; i++) {
		int j = i + 1;
		strcpy(array[i].id, array[j].id);
		strcpy(array[i].company, array[j].company);
		strcpy(array[i].departure, array[j].departure);
		strcpy(array[i].arrival, array[j].arrival);
		strcpy(array[i].vehicle, array[j].vehicle);
		array[i].seats = array[j].seats;
		array[i].date.day = array[j].date.day;
		array[i].date.month = array[j].date.month;
		array[i].date.year = array[j].date.year;
		array[i].estimated_departure.hours = array[j].estimated_departure.hours;
		array[i].estimated_departure.minutes =
				array[j].estimated_departure.minutes;
		array[i].duration.hours = array[j].duration.hours;
		array[i].duration.minutes = array[j].duration.minutes;
		j++;
		flag2 = 1;
	}
	if (flag2 == 1) {
		input = fopen("flights.csv", "w");

		if ((input = fopen("flights.csv", "w")) == NULL) {
			printf("\nFile not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			x = x - 1;
			flag3 = flightsPrinter(input, array, x);
		}
	}
	rewind(input);
	fclose(input);
	flag = flagChecker(flag2, flag3);
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 * 	File must exists.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsView(flights array[], int x) {
	int flag = 0;

	for (int i = 0; i < x; i++) {
		printf("\n%d° fly."
				"\nFly ID: %s"
				"\nCompany: %s"
				"\nDeparture: %s"
				"\nArrival: %s"
				"\nVehicle: %s"
				"\nSeats: %d"
				"\nFly date: %d-%d-%d"
				"\nEstimated departure: %d'' %d'"
				"\nDuration: %d'' %d'\n", i, array[i].id, array[i].company,
				array[i].departure, array[i].arrival, array[i].vehicle,
				array[i].seats, array[i].date.day, array[i].date.month,
				array[i].date.year, array[i].estimated_departure.hours,
				array[i].estimated_departure.minutes, array[i].duration.hours,
				array[i].duration.minutes);
		flag = 1;
	}
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Array will be equals.
 * 	Flag will be 1 if success, 0 else.
 */
int flightsCloner(flights array[], int x, flights temp[]) {
	int flag = 0;

	for (int i = 0; i < x; i++) {
		temp[i] = array[i];
		flag = 1;
	}
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsSearch_Company(flights array[], int x) {
	char option = 'y', company[LEN], subsearch = 'y';

	int flag = 0;

	while (option == 'y') {
		system("clear");
		printf("\nDo you want to search by company name? [y/n]: ");
		scanf("%c", &option);

		if (option == 'y') {		//start search
			printf("\nInsert name: ");
			scanf("%s", company);
			while (strlen(company) < 2) {
				printf("\nInvalid company name.\n"
						"Please, insert a valid company name (min 2 chars.): ");
				scanf("%s", company);
			}

			for (int i = 0; i < x; i++) {
				if (strcasecmp(array[i].company, company) == 0) {
					printf("\n%d° fly."
							"\nFly ID: %s"
							"\nCompany: %s"
							"\nDeparture: %s"
							"\nArrival: %s"
							"\nVehicle: %s"
							"\nSeats: %d"
							"\nFly date: %d-%d-%d"
							"\nEstimated departure: %d'' %d'"
							"\nDuration: %d'' %d'\n", i, array[i].id,
							array[i].company, array[i].departure,
							array[i].arrival, array[i].vehicle, array[i].seats,
							array[i].date.day, array[i].date.month,
							array[i].date.year,
							array[i].estimated_departure.hours,
							array[i].estimated_departure.minutes,
							array[i].duration.hours, array[i].duration.minutes);
					flag = 1;
				} //end strcasecmp
			} //end for

			printf(
					"\n\nSearch completed.\n"
							"Do you want to expand the search with a sub-string search? [y/n]: ");
			getchar();
			scanf("%c", &subsearch);

			if (subsearch == 'y') {
				printf("\nInsert a word to search for: ");
				scanf("%s", company);
				while (strlen(company) < 1) { //1 is the minimum lenght to search, this will avoid the search by a blank string
					printf("\nCan't search an empty word.\n"
							"Please, insert a valid word(min 1 char.): ");
					scanf("%s", company);
				}

				for (int i = 0; i < x; i++) {
					if (strstr(array[i].company, company) == NULL) {
						printf("\nNo match results in %d passenger.", i);
					} else {	//if elements are found
						printf("\n%d° fly."
								"\nFly ID: %s"
								"\nCompany: %s"
								"\nDeparture: %s"
								"\nArrival: %s"
								"\nVehicle: %s"
								"\nSeats: %d"
								"\nFly date: %d-%d-%d"
								"\nEstimated departure: %d'' %d'"
								"\nDuration: %d'' %d'\n", i, array[i].id,
								array[i].company, array[i].departure,
								array[i].arrival, array[i].vehicle,
								array[i].seats, array[i].date.day,
								array[i].date.month, array[i].date.year,
								array[i].estimated_departure.hours,
								array[i].estimated_departure.minutes,
								array[i].duration.hours,
								array[i].duration.minutes);
					}	//end elements found
				}	//end sub search
			}	//end subsearch request
		}	//end search
	}	//end search while
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsSearch_Departure(flights array[], int x) {
	char option = 'y', departure[LEN], subsearch = 'y';

	int flag = 0;

	while (option == 'y') {
		system("clear");
		printf("\nDo you want to search by departure? [y/n]: ");
		scanf("%c", &option);

		if (option == 'y') {		//start search
			printf("\nInsert departure: ");
			scanf("%s", departure);
			while (strlen(departure) < 2) {
				printf("\nInvalid departure name.\n"
						"Please, insert a valid departure (min 2 chars.): ");
				scanf("%s", departure);
			}

			for (int i = 0; i < x; i++) {
				if (strcasecmp(array[i].departure, departure) == 0) {
					printf("\n%d° fly."
							"\nFly ID: %s"
							"\nCompany: %s"
							"\nDeparture: %s"
							"\nArrival: %s"
							"\nVehicle: %s"
							"\nSeats: %d"
							"\nFly date: %d-%d-%d"
							"\nEstimated departure: %d'' %d'"
							"\nDuration: %d'' %d'\n", i, array[i].id,
							array[i].company, array[i].departure,
							array[i].arrival, array[i].vehicle, array[i].seats,
							array[i].date.day, array[i].date.month,
							array[i].date.year,
							array[i].estimated_departure.hours,
							array[i].estimated_departure.minutes,
							array[i].duration.hours, array[i].duration.minutes);
					flag = 1;
				} //end strcasecmp
			} //end for

			printf(
					"\n\nSearch completed.\n"
							"Do you want to expand the search with a sub-string search? [y/n]: ");
			getchar();
			scanf("%c", &subsearch);

			if (subsearch == 'y') {
				printf("\nInsert a word to search for: ");
				scanf("%s", departure);
				while (strlen(departure) < 1) {
					printf("\nCan't search an empty word.\n"
							"Please, insert a valid word(min 1 char.): ");
					scanf("%s", departure);
				}

				for (int i = 0; i < x; i++) {
					if (strstr(array[i].departure, departure) == NULL) {
						printf("\nNo match results in %d passenger.", i);
					} else {	//if elements are found
						printf("\n%d° fly."
								"\nFly ID: %s"
								"\nCompany: %s"
								"\nDeparture: %s"
								"\nArrival: %s"
								"\nVehicle: %s"
								"\nSeats: %d"
								"\nFly date: %d-%d-%d"
								"\nEstimated departure: %d'' %d'"
								"\nDuration: %d'' %d'\n", i, array[i].id,
								array[i].company, array[i].departure,
								array[i].arrival, array[i].vehicle,
								array[i].seats, array[i].date.day,
								array[i].date.month, array[i].date.year,
								array[i].estimated_departure.hours,
								array[i].estimated_departure.minutes,
								array[i].duration.hours,
								array[i].duration.minutes);
					}	//end elements found
				}	//end sub search
			}	//end subsearch request
		}	//end search
	}	//end search while
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsSearch_Arrival(flights array[], int x) {
	char option = 'y', arrival[LEN], subsearch = 'y';

	int flag = 0;

	while (option == 'y') {
		system("clear");
		printf("\nDo you want to search by arrival? [y/n]: ");
		scanf("%c", &option);

		if (option == 'y') {		//start search
			printf("\nInsert arrival: ");
			scanf("%s", arrival);
			while (strlen(arrival) < 2) {
				printf("\nInvalid arrival name.\n"
						"Please, insert a valid arrival (min 2 chars.): ");
				scanf("%s", arrival);
			}

			for (int i = 0; i < x; i++) {
				if (strcasecmp(array[i].arrival, arrival) == 0) {
					printf("\n%d° fly."
							"\nFly ID: %s"
							"\nCompany: %s"
							"\nDeparture: %s"
							"\nArrival: %s"
							"\nVehicle: %s"
							"\nSeats: %d"
							"\nFly date: %d-%d-%d"
							"\nEstimated departure: %d'' %d'"
							"\nDuration: %d'' %d'\n", i, array[i].id,
							array[i].company, array[i].departure,
							array[i].arrival, array[i].vehicle, array[i].seats,
							array[i].date.day, array[i].date.month,
							array[i].date.year,
							array[i].estimated_departure.hours,
							array[i].estimated_departure.minutes,
							array[i].duration.hours, array[i].duration.minutes);
					flag = 1;
				} //end strcasecmp
			} //end for

			printf(
					"\n\nSearch completed.\n"
							"Do you want to expand the search with a sub-string search? [y/n]: ");
			getchar();
			scanf("%c", &subsearch);

			if (subsearch == 'y') {
				printf("\nInsert a word to search for: ");
				scanf("%s", arrival);
				while (strlen(arrival) < 1) {
					printf("\nCan't search an empty word.\n"
							"Please, insert a valid word(min 1 char.): ");
					scanf("%s", arrival);
				}

				for (int i = 0; i < x; i++) {
					if (strstr(array[i].company, arrival) == NULL) {
						printf("\nNo match results in %d passenger.", i);
					} else {	//if elements are found
						printf("\n%d° fly."
								"\nFly ID: %s"
								"\nCompany: %s"
								"\nDeparture: %s"
								"\nArrival: %s"
								"\nVehicle: %s"
								"\nSeats: %d"
								"\nFly date: %d-%d-%d"
								"\nEstimated departure: %d'' %d'"
								"\nDuration: %d'' %d'\n", i, array[i].id,
								array[i].company, array[i].departure,
								array[i].arrival, array[i].vehicle,
								array[i].seats, array[i].date.day,
								array[i].date.month, array[i].date.year,
								array[i].estimated_departure.hours,
								array[i].estimated_departure.minutes,
								array[i].duration.hours,
								array[i].duration.minutes);
					}	//end elements found
				}	//end sub search
			}	//end subsearch request
		}	//end search
	}	//end search while
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsSearch_Vehicle(flights array[], int x) {
	char option = 'y', vehicle[LEN], subsearch = 'y';

	int flag = 0;

	while (option == 'y') {
		system("clear");
		printf("\nDo you want to search by vehicle? [y/n]: ");
		scanf("%c", &option);

		if (option == 'y') {		//start search
			printf("\nInsert vehicle: ");
			scanf("%s", vehicle);
			while (strlen(vehicle) < 2) {
				printf("\nInvalid vehicle name.\n"
						"Please, insert a valid vehicle (min 2 chars.): ");
				scanf("%s", vehicle);
			}

			for (int i = 0; i < x; i++) {
				if (strcasecmp(array[i].vehicle, vehicle) == 0) {
					printf("\n%d° fly."
							"\nFly ID: %s"
							"\nCompany: %s"
							"\nDeparture: %s"
							"\nArrival: %s"
							"\nVehicle: %s"
							"\nSeats: %d"
							"\nFly date: %d-%d-%d"
							"\nEstimated departure: %d'' %d'"
							"\nDuration: %d'' %d'\n", i, array[i].id,
							array[i].company, array[i].departure,
							array[i].arrival, array[i].vehicle, array[i].seats,
							array[i].date.day, array[i].date.month,
							array[i].date.year,
							array[i].estimated_departure.hours,
							array[i].estimated_departure.minutes,
							array[i].duration.hours, array[i].duration.minutes);
					flag = 1;
				} //end strcasecmp
			} //end for

			printf(
					"\n\nSearch completed.\n"
							"Do you want to expand the search with a sub-string search? [y/n]: ");
			getchar();
			scanf("%c", &subsearch);

			if (subsearch == 'y') {
				printf("\nInsert a word to search for: ");
				scanf("%s", vehicle);
				while (strlen(vehicle) < 1) {
					printf("\nCan't search an empty word.\n"
							"Please, insert a valid word(min 1 char.): ");
					scanf("%s", vehicle);
				}

				for (int i = 0; i < x; i++) {
					if (strstr(array[i].company, vehicle) == NULL) {
						printf("\nNo match results in %d passenger.", i);
					} else {	//if elements are found
						printf("\n%d° fly."
								"\nFly ID: %s"
								"\nCompany: %s"
								"\nDeparture: %s"
								"\nArrival: %s"
								"\nVehicle: %s"
								"\nSeats: %d"
								"\nFly date: %d-%d-%d"
								"\nEstimated departure: %d'' %d'"
								"\nDuration: %d'' %d'\n", i, array[i].id,
								array[i].company, array[i].departure,
								array[i].arrival, array[i].vehicle,
								array[i].seats, array[i].date.day,
								array[i].date.month, array[i].date.year,
								array[i].estimated_departure.hours,
								array[i].estimated_departure.minutes,
								array[i].duration.hours,
								array[i].duration.minutes);
					}	//end elements found
				}	//end sub search
			}	//end subsearch request
		}	//end search
	}	//end search while
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsSearch(flights array[], int x) {
	int select = 0, flag = 0;

	while (select != 5) {
		system("clear");
		printf("\t\t---Search menu for flights---"
				"\n\t(1) Search fly by departure;"
				"\n\t(2) Search fly by arrival;"
				"\n\t(3) Search fly by company;"
				"\n\t(4) Search fly by vehicle;"
				"\n\t(5) Return.\n\n"
				"Select an option [1-5]: ");
		scanf("%d", &select);

		switch (select) {
		case 1:
			flag = flightsSearch_Departure(array, x);
			break;
		case 2:
			flag = flightsSearch_Arrival(array, x);
			break;
		case 3:
			flag = flightsSearch_Company(array, x);
			break;
		case 4:
			flag = flightsSearch_Vehicle(array, x);
			break;
		case 5:
			printf("\n\nReturning...");
			break;
		default:
			system("clear");
			getchar();
			printf("\n\nWrong selection."
					"\nPress ENTER key to retry.");
			getchar();
			getchar();
			break;
		}
	}
	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsIncreasingBubbleSort_Month(flights test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;

	flights temp;

	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].date.month < test[min_idx].date.month) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;
	}

	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsDecreasingBubbleSort_Month(flights test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;

	flights temp;

	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].date.month > test[min_idx].date.month) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;
	}

	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsIncreasingBubbleSort_Seats(flights test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;

	flights temp;

	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].seats < test[min_idx].seats) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;
	}

	return flag;
}

/**
 * Pre-conditions:
 * 	Flights array must be alredy loaded.
 *
 * Post conditions:
 * 	Flag will be 1 if success, 0 else.
 */
int flightsDecreasingBubbleSort_Seats(flights test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;

	flights temp;

	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].seats > test[min_idx].seats) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;
	}

	return flag;
}

/**
 * Pre-conditions:
 * 	Array must be alredy laoded.
 * 	File flights.csv must exist.
 *
 * 	Post-conditions:
 * 	Check function will be called to read
 * 	the functions return value.
 */
void flightsSortingMenu(void) {
	int menu = 0, n = 0, flagLoad = 0, flagCheck = 0, flagView = 0, flagVerify =
			0, flag = 0;

	FILE *flightsPtr;	//initialize pointer

	while (menu != 5) {

		fflush(stdin);
		fflush(stdout);

		flightsPtr = fopen("flights.csv", "r");	//initialize pointer to file in read mode

		n = rowCount(flightsPtr, "flights.csv");

		flights flights[n], sorted[n];

		if ((flightsPtr = fopen("flights.csv", "r")) == NULL) {
			system("clear");
			printf("\nFile not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flagLoad = flightsLoad(flightsPtr, flights, n);
			flagCheck = flightsCloner(flights, n, sorted);
			flagVerify = flagChecker(flagLoad, flagCheck);
			system("clear");
			printf("\t\t---Sorting Menù---\n"
					"\n\t(1) Increasing sort by fly month;"
					"\n\t(2) Decreasing sort by fly month;"
					"\n\t(3) Increasing sort by max number of seats;"
					"\n\t(4) Decreasing sort by max number of seats;"
					"\n\t(5) Exit.\n\n"
					"Select an option [1-5]: ");
			scanf("%d", &menu);

			switch (menu) {
			case 1:
				flag = flightsIncreasingBubbleSort_Month(sorted, n);
				flagVerify = flagChecker(flagVerify, flag);
				flagView = flightsView(sorted, n);
				flagVerify = flagChecker(flagVerify, flagView);
				flagMessage(flagVerify);
				break;
			case 2:
				flag = flightsDecreasingBubbleSort_Month(sorted, n);
				flagVerify = flagChecker(flagVerify, flag);
				flagView = flightsView(sorted, n);
				flagVerify = flagChecker(flagVerify, flagView);
				flagMessage(flagVerify);
				break;
			case 3:
				flag = flightsIncreasingBubbleSort_Seats(sorted, n);
				flagVerify = flagChecker(flagVerify, flag);
				flagView = flightsView(sorted, n);
				flagVerify = flagChecker(flagVerify, flagView);
				flagMessage(flagVerify);
				break;
			case 4:
				flag = flightsDecreasingBubbleSort_Seats(sorted, n);
				flagVerify = flagChecker(flagVerify, flag);
				flagView = flightsView(sorted, n);
				flagVerify = flagChecker(flagVerify, flagView);
				flagMessage(flagVerify);
				break;
			case 5:
				printf("\n\nReturning...");
				break;
			default:
				system("clear");
				getchar();
				printf("\n\nWrong selection."
						"\nPress ENTER key to retry.");
				getchar();
				getchar();
				break;
			}
		}
	}
}

/**
 * Pre-conditions:
 * 	Array must be alredy laoded.
 * 	File flights.csv must exist.
 *
 * 	Post-conditions:
 * 	Check function will be called to read
 * 	the functions return value.
 */
void flightsMenu_AdministratorOnly(void) {
	int menu = 0, flagLoad = 0, n = 0, flag1 = 0, flagVerify = 0;

	FILE *flightsPtr;

	while (menu != 6) {

		fflush(stdin);
		fflush(stdout);

		flightsPtr = fopen("flights.csv", "r");

		n = rowCount(flightsPtr, "flights.csv");

		flights flights[n];

		if ((flightsPtr = fopen("flights.csv", "r")) == NULL) {
			system("clear");
			printf("\nFile not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flagLoad = flightsLoad(flightsPtr, flights, n);

			system("clear");

			printf("\n\t\t---Flights Menu---\n"
					"(1) Add a fly;"
					"\n(2) Edit a fly;"
					"\n(3) Delete a fly;"
					"\n(4) Sorting menù;"
					"\n(5) Access fly search menù;"
					"\n(6) Return."
					"\n\nSelect an option [1-6]: ");
			scanf("%d", &menu);

			switch (menu) {
			case 1:
				flag1 = flightsAdd(flightsPtr);
				flagVerify = flagChecker(flagLoad, flag1);
				flagMessage(flagVerify);
				break;

			case 2:
				flag1 = flightsEditor(flightsPtr, flights, n);
				flagVerify = flagChecker(flagLoad, flag1);
				flagMessage(flagVerify);
				break;

			case 3:
				flag1 = flightsDelete(flightsPtr, flights, n);
				flagVerify = flagChecker(flagLoad, flag1);
				flagMessage(flagVerify);
				break;

			case 4:
				flightsSortingMenu();
				break;

			case 5:
				flag1 = flightsSearch(flights, n);
				flagVerify = flagChecker(flagLoad, flag1);
				flagMessage(flagVerify);
				break;
			case 6:
				system("clear");
				printf("Returning...\n\n");
				break;
			default:
				system("clear");
				getchar();
				printf("\n\nWrong selection."
						"\nPress ENTER key to retry.");
				getchar();
				getchar();
				break;
			}
		}
	}
}

