/**
 *
 * @file passengers.h
 *
 *	In this header file are contained all the methods
 *	and functions related to passengers, divided by
 *	administrator-side and user-side.
 *
 *	Those functions and methods guarantee all the
 *	operations provided for passengers, divided by
 *	admin-side and user-side.
 *
 * 	@version 1
 * 	@date 08/06/2019
 * 	@authors Lorenzo Baldari
 * 	@copyright GNU GPL
 *
 */


#ifndef PASSENGERS_H_
#define PASSENGERS_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 * Max admissible value for string lenght.
 */
#define LEN 20

/**
 * Max admissible  value for passport ID.
 */
#define PASSPORT 10

/**
 * Max and min value for passport ID.
 * Used for defensive programmation scopes.
 */
#define MAXMINPASSPORT 9

/**
 * Max and min value for strings.
 * Used for defensive programmation scopes.
 */
#define MAX_LEN 19
#define MIN_LEN 3

/**
 * Min value for sub-string search.
 * Used for defensive programmation scopes.
 */
#define MIN_SUBSEARCH 1

/**
 * 	Date struct.
 * 	Defined to create day/month/year structure.
 */
typedef struct date {

	int day, month, year;

} date;

/**
 * Passengers struct.
 * Defined to assign parameters to
 * passengers.
 */
typedef struct passengers {

	char name[LEN], surname[LEN], username[LEN];

	date birth_date, signup_date;

	char passport_number[PASSPORT];

} passengers;

void flagMessage(int x);	//output message based on int value
int rowCount(FILE *input, char *file_name);	//count rows in a file
int flagChecker(int x, int y);	//check flag: flag AND flag

/**
 * This function will load passengers
 * from file to array
 *
 * @param input Pointer to file
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersLoad(FILE *input, passengers array[], int x);

/**
 * This function will print to file "passengers.csv"
 * all the passengers data stored into array
 *
 * @param input Pointer to file
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersPrinter(FILE *input, passengers array[], int x);

/**
 *
 * This function will add a passenger into a temporary
 * array.
 *
 * @param input Pointer to file
 * @return flag 1 if success, else 0
 */
int passengersAdd(FILE *input);	//add a passenger

/**
 *
 * This function edit a passenger account (as user).
 * After a login, it will request the user to
 * edit data.
 *
 * @param input Pointer to file
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersEditor(FILE *input, passengers array[], int x);

/**
 *
 * This function edit a passenger account (as administrator).
 * After inserting username, it will request the administrator
 * to edit data.
 *
 * @param input Pointer to file
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersEditor_Admin(FILE *input, passengers array[], int x);

/**
 *
 * This function will delete a passenger account ( as user).
 * After inserting username and passport number, it will
 * request the user for confirmation.
 *
 * @param input Pointer to file
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersDeleter(FILE *input, passengers array[], int x);

/**
 *
 * This function will delete a passenger account ( as admin).
 * After inserting username, it will
 * request the admin for confirmation.
 *
 * @param input Pointer to file
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersDeleter_Admin(FILE *input, passengers array[], int x);

/**
 *
 * This function will print to display the
 * content stored in passengers array
 *
 * @param array	Passengers array
 * @param x	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int passengersView(passengers array[], int x);

/**
 *
 * This function will clone passengers
 * array into another
 *
 * @param array	Passengers array
 * @param x	Dimension of passengers array
 * @param temp	Temporary array
 * @return
 */
int passengersCloner(passengers array[], int x, passengers temp[]);

/**
 *
 * This function will execute a decreasing bubblesort
 * based on passenger sign-up year
 *
 * @param test Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersDecreasingBubbleSort_Signupyear(passengers test[], int x);

/**
 *
 * This function will execute a decreasing bubblesort
 * based on passenger birth year
 *
 * @param test Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersDecreasingBubbleSort_Birthyear(passengers test[], int x);

/**
 *
 * This function will execute an increasing bubblesort
 * based on passenger sign-up year
 *
 * @param test Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersIncreasingBubbleSort_Signupyear(passengers test[], int x);

/**
 *
 * This function will execute an increasing bubblesort
 * based on passenger birth year
 *
 * @param test Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersIncreasingBubbleSort_Birthyear(passengers test[], int x);

/**
 *
 * This function will search a passengers stored into
 * passenger's array by name.
 *
 * @param array	Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersSearch_Name(passengers array[], int x);

/**
 *
 * This function will search a passengers stored into
 * passenger's array by surname.
 *
 * @param array	Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersSearch_Surname(passengers array[], int x);

/**
 *
 * This function will search a passengers stored into
 * passenger's array by username.
 *
 * @param array	Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersSearch_Username(passengers array[], int x);

/**
 *
 * This function will search a passengers stored into
 * passenger's array by birth year.
 *
 * @param array	Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersSearch_BirthYear(passengers array[], int x);

/**
 *
 * This function will search a passengers stored into
 * passenger's array by sign-up year.
 *
 * @param array	Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersSearch_SignupYear(passengers array[], int x);

/**
 *
 * This function will open the passengers search menu.
 *
 * @param array	Passengers array
 * @param x	Array dimension
 * @return
 */
int passengersSearch(passengers array[], int x);

/**
 * This method will open the passengers sorting menu.
 */
void passengersSortingMenu(void);

/**
 * This method will open the passengers
 * administrators menu.
 */
void administratorMenu(void);

/**
 * This method will open the passengers
 * user menu.
 */
void passengersMenu(void);

#endif /* PASSENGERS_H_ */
