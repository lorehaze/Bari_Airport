/*
 * bookings.c
 *
 *  Created on: 25 mag 2019
 *      Author: lorenzo
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 * Max admissible value for string lenght.
 */
#define LEN 20

/**
 * Max admissible  value for passport ID.
 */
#define PASSPORT 10

/**
 * Max and min value for passport ID.
 * Used for defensive programmation scopes.
 */
#define PASSPORT_LEN 9

/**
 * Max and min admissible value for
 * string lenght.
 * Used by defensive programmation scopes.
 */
#define MAX_LEN 19

#define MIN_LEN 3

/**
 * Default booking number.
 */
#define DEFAULT_BOOKING 1

/**
 * Structure defined to contain all the bookings data
 * defined by fields.
 */
typedef struct bookings {
	char booking_id[LEN], username[LEN], fly_id[LEN], departure[LEN],
			arrival[LEN];
	int check_in, boarded;
} bookings;

/**
 * Structure defined to contain time value
 * defined in hours and minutes.
 */
typedef struct time {
	int hours, minutes;
} time;

/**Structure defined to contain date value
 * defined by day, month and year.
 */
typedef struct date {

	int day, month, year;

} date;

/**
 * Structure defined to contain
 * all the fields required
 * to identify a flight.
 */
typedef struct flights {
	char id[LEN], company[LEN], departure[LEN], arrival[LEN], vehicle[LEN];

	int seats;

	date date;

	time estimated_departure;

	time duration;

} flights;

/**
 * Passengers struct.
 * Defined to assign parameters to
 * passengers.
 */
typedef struct passengers {

	char name[LEN], surname[LEN], username[LEN];

	date birth_date, signup_date;

	char passport_number[PASSPORT];

} passengers;

/**
 * Pre-condition:
 *	 bookings array must be defined by a dimension.
 *
 * Post-condition:
 * 	Bookings array will be empty.
 */
void bookingsCleaner(bookings array[], int b_dim) {
	for (int i = 0; i < b_dim; i++) {
		memset(array[i].booking_id, 0, strlen(array[i].booking_id)); //cleaning array
		memset(array[i].arrival, 0, strlen(array[i].arrival));
		memset(array[i].departure, 0, strlen(array[i].departure));
		memset(array[i].fly_id, 0, strlen(array[i].fly_id));
		memset(array[i].username, 0, strlen(array[i].username));
		array[i].check_in = 0;
		array[i].boarded = 0;
	}
}

/**
 * 	Pre-condition:
 * 		Bookings array must be loaded with data from
 * 		bookings.csv.
 *
 * 	Post-condition:
 * 		Only passengers with boarding field == 0 will be shown.
 */
void nonboarded(bookings b_array[], int b_dim) {
	for (int i = 0; i < b_dim; i++) {
		if ((b_array[i].boarded == 0) && (b_array[i].check_in = 1)) {
			printf("\n%s: not boarded.\n", b_array[i].username);
		}
	}
}

/**
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 *
 * 	Post-condition:
 * 		The bookings array will contain all the data stored in
 * 		bookings.csv file.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 */
int bookingsLoad(FILE *input, bookings array[], int x) {
	int flag = 0;	//initialized to 0

	for (int i = 0; i < x; i++) {
		fscanf(input,
				"%[^,],%[^,],%[^,],%[^,],%[^,],%d,%d\n",		//load format
				array[i].username, array[i].fly_id, array[i].booking_id,
				array[i].departure, array[i].arrival, &array[i].boarded,
				&array[i].check_in);
		flag = 1;	//load ok
	}
	rewind(input);	//rewind pointer
	fclose(input);	//close pointer
	return flag;//the value will return 0 if load failed, 1 in case of success
}

/**
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		The bookings,csv file will contain all the data added in
 * 		bookings array. The file is opened in append mode.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 */
int bookingsPrinter(FILE *input, bookings array[], int x) {
	int flag = 0;	//initialized to 0

	for (int i = 0; i < x; i++) {
		fprintf(input, "%s,%s,%s,%s,%s,%d,%d\n",
				array[i].username,	//print format
				array[i].fly_id, array[i].booking_id, array[i].departure,
				array[i].arrival, array[i].boarded, array[i].check_in);
		flag = 1;
	}
	rewind(input);	//rewind
	fclose(input);	//close
	return flag;
}

/**
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		The bookings.csv file will contain all the data contained in
 * 		bookings array, including the edited one. The file is opened in w mode.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 */
int bookingsEdit(FILE *input, bookings b_array[], int b_dim, flights f_array[],
		int f_dim) {

	char username[LEN];

	int booking_index = 0, flight_index = 0, flagPrint=0;

	system("clear");

	printf("\nInsert your username: ");
	scanf("%s", username);
	while ((strlen(username) < 3) || (strlen(username) > 19)) {
		printf("\nInvalid username."
				"\nPlease, insert a valid one: ");
		scanf("%s", username);
	}

	for (int i = 0; i < b_dim; i++) {
		if (strcasecmp(b_array[i].username, username) == 0) {
			booking_index = i;
		}
	}

	printf("\nAvailable flights: \n");

	for (int j = 0; j < f_dim; j++) {
		printf("%d° flight - ID: %s --- %s-%s\n", j, f_array[j].id,
				f_array[j].departure, f_array[j].arrival);
	}

	printf("\nSelect a flight: ");
	scanf("%d", &flight_index);
	while (flight_index > f_dim - 1) {		//control over flight index
				printf("\nInvalid flight number."
						"\nPlease, insert a valid one: ");
				scanf("%d", &flight_index);
			}

	printf("\n\nYou selected the %d flight."
			"\nPress ENTER key to confirm.", flight_index);
	getchar();
	getchar();

	//clean it first

	memset(b_array[booking_index].booking_id, 0,
			strlen(b_array[booking_index].booking_id));
	memset(b_array[booking_index].arrival, 0,
			strlen(b_array[booking_index].arrival));
	memset(b_array[booking_index].departure, 0,
			strlen(b_array[booking_index].departure));
	memset(b_array[booking_index].fly_id, 0,
			strlen(b_array[booking_index].fly_id));
	b_array[booking_index].check_in = 0;
	b_array[booking_index].boarded = 0;

	strcpy(b_array[booking_index].fly_id, f_array[flight_index].id);
	strcpy(b_array[booking_index].arrival, f_array[flight_index].arrival);
	strcpy(b_array[booking_index].departure, f_array[flight_index].departure);
	strncpy(b_array[booking_index].booking_id, b_array[booking_index].username,
			2);
	strncat(b_array[booking_index].booking_id, f_array[flight_index].id, 3);
	strncat(b_array[booking_index].booking_id, f_array[flight_index].company,
			2);

	int flag = 1;
	input = fopen("bookings.csv", "w");

		if ((input = fopen("bookings.csv", "w")) == NULL) {
			printf("\n\nFile bookings.csv not found."
					"\nI'll create one."
					"\nPress ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flagPrint = bookingsPrinter(input, b_array, b_dim);
		}
		rewind(input);
		fclose(input);

		flag = flagChecker(flag, flagPrint);

		return flag;
}

/**
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		The bookings.csv file will contain all the data contained into
 * 		bookings array, minus the deleted one. The file is opened in w mode.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 */
int bookingsDelete(FILE *input, bookings b_array[], int b_dim) {

	char select = 'y', username[LEN];
	int delete_index = 0, flagDelete = 0, flagPrint = 0, flag = 0;

	system("clear");
	getchar();
	printf("\n\nDo you want to delete your booking? [y/n]: ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		printf("\nInvalid option."
				"\nPlease, select a valid one: ");
		scanf("%c", &select);
	}

	if (select == 'y') {

		memset(username, 0, strlen(username));	//clean username

		printf("\nInsert your username: ");
		scanf("%s", username);		//get username
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {//control over username
			printf("\n\nInvalid username."
					"\nPlease, insert a valid one: ");
			scanf("%s", username);
		}

		for (int i = 0; i < b_dim; i++) {
			if (strcasecmp(b_array[i].username, username) == 0) {//check username matching
				delete_index = i;	//set delete index to i-element matched
			}
		}

		for (int j = delete_index; j < b_dim; j++) {//move the next k elements to j-deleted
			int k = j + 1;

			strcpy(b_array[j].arrival, b_array[k].arrival);
			strcpy(b_array[j].departure, b_array[k].departure);
			strcpy(b_array[j].booking_id, b_array[k].booking_id);
			strcpy(b_array[j].fly_id, b_array[k].fly_id);
			strcpy(b_array[j].username, b_array[k].username);
			b_array[j].boarded = b_array[k].boarded;
			b_array[j].check_in = b_array[k].check_in;
			j++;
			flagDelete = 1;			//if delete successful, set flagDelete to 1
		}

		input = fopen("bookings.csv", "w");	//pointer is pointing to file, opened in write

		if ((input = fopen("bookings.csv", "w")) == NULL) {	//check over file
			printf("\nFile not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			b_dim = b_dim - 1;//reduce the array dimension because of the deleted element
			flagPrint = bookingsPrinter(input, b_array, b_dim);	//flagPrint will be 1 if print successful
		}
	}
	flag = flagChecker(flagDelete, flagPrint);//flag will be 1 if all the operations are successfull and returned 1

	return flag;
}

/**
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		The bookings.csv will contain all the new updated data, including
 * 		all the bookings passed to check-in.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 */
int checkIn(FILE *input, bookings b_array[], int b_dim, flights f_array[],
		int f_dim) {
	char select = 'y', username[LEN], temp[LEN], booking[LEN];
	int booking_index = 0, flight_index = 0, flagPrint = 0, flag = 0;

	system("clear");
	getchar();
	printf("\n\nDo you want to start the check-in? [y/n]: ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		printf("\nInvalid option."
				"\nPlease, select a valid one: ");
		scanf("%c", &select);
	}

	if (select == 'y') {

		memset(username, 0, strlen(username));	//clean username

		printf("\nInsert your username: ");		//get username
		scanf("%s", username);
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {
			printf("\nInvalid username."
					"Please, insert a valid one: ");
			scanf("%s", username);
		}

		for (int i = 0; i < b_dim; i++) {
			if (strcasecmp(b_array[i].username, username) == 0) {//if username matches
				booking_index = i;	//set booking index to i-element
			}
		}

		memset(temp, 0, strlen(temp));	//clean temp

		strcpy(temp, b_array[booking_index].booking_id); //copy booking id into temp

		memset(booking, 0, strlen(booking));	//clean booking
		printf("\nInsert your booking ID: ");	//get booking
		scanf("%s", booking);
		while ((strlen(booking) < MIN_LEN) || (strlen(booking) > MAX_LEN)) {
			printf("\nInvalid booking ID."
					"Please, insert a valid one: ");
			scanf("%s", booking);
		}

		if (strcasecmp(temp, booking) == 0) {//if booking id match found, set both flag and check_in to 1
			system("clear");
			printf("\n\nLogin successful."
					"\nPress ENTER key to confirm the check-in.");
			flag = 1;		//return value to show that check in is successful.
			b_array[booking_index].check_in = 1;	//set check in to 1
			getchar();
			getchar();
		}
	}

	int assigned_seat = 1 + rand() % 100;

	for (int j = 0; j < f_dim; j++) {
		for (int k = 0; k < b_dim; k++) {
			if (strcasecmp(f_array[j].id, b_array[k].fly_id) == 0) {
				flight_index = j;
			}
		}
	}

	f_array[flight_index].seats = f_array[flight_index].seats - 1;

	input = fopen("flights.csv", "w");
	flightsPrinter(input, f_array, f_dim);
	fclose(input);

	input = fopen("bookings.csv", "r+");	//open "bookings.csv" for the update

	if ((input = fopen("bookings.csv", "r+")) == NULL) {
		printf("\n\nFile bookings.csv not found."
				"Press ENTER key to continue.");
		getchar();
		getchar();
	} else {
		flagPrint = bookingsPrinter(input, b_array, b_dim);	//check if check in and print are successful
		system("clear");
		printf("\n\nCheck in successful.\n");
		rewind(input);		//rewind stream
		fclose(input);		//close file
	}

	flag = flagChecker(flag, flagPrint);//if flag and flagPrint are 1, the results to return will be 1

	return flag;
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		File bookings.csv will contain all the updated data, including
 * 		all the passengers who used the boarding function.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 *
 */
void boarding(FILE *input, passengers p_array[], int p_dim, bookings b_array[],
		int b_dim, long int *offset) {

	char username[LEN];

	int booking_index = -1, flag = 0;//se la ricerca va male resta -1, altrimenti 0

	//printf("%lu", *offset);

	printf("\n\nInsert a username: ");
	scanf("%s", username);
	while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {
		printf("\n\nInvalid username."
				"Please, insert a valid one: ");
		scanf("%s", username);
	}

	for (int j = 0; j < b_dim; j++) {
		if (strcasecmp(b_array[j].username, username) == 0) {
			booking_index = j;
			flag = 1;	//if match found
		}
	}

	if (flag == 1) {
		input = fopen("boarding.dat", "wb");

		if ((input = fopen("boarding.dat", "wb")) == NULL) {
			printf("\nFilw boarding.dat not found."
					"I'll create one."
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			fseek(input, *offset, SEEK_SET);
			fwrite(&b_array[booking_index], sizeof(bookings), 1, input);
			*offset = *offset + sizeof(bookings);
			rewind(input);
			fclose(input);

			input = fopen("bookings.csv", "r+");

			if ((input = fopen("bookings.csv", "r+")) == NULL) {
				printf("\nFile not found.");
			} else {
				b_array[booking_index].boarded = 1;
				bookingsPrinter(input, b_array, b_dim);
				rewind(input);
				fclose(input);
				printf("\nPassenger successfully boarded.\n"
						"Press ENTER key to continue.");
				getchar();
				getchar();
			}
		}
	} else if (flag == 0) {
		printf("\nNo matches found."
				"Press ENTER key to return.");
		getchar();
		getchar();
	}

	char select = 'y';

	if (flag == 1) {
		system("clear");
		getchar();
		printf("\nDo you want to view your booking?[y/n]: ");
		scanf("%c", &select);

		if (select == 'y') {
			fread(&b_array[booking_index], sizeof(bookings), 1, input);
			printf("%s", b_array[booking_index].username);
			printf("\nPress ENTER key to return.");
			getchar();
			getchar();
		}
	}
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		File bookings.csv will contain all the updated data, including
 * 		all the bookings added by the passenger.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 *
 */
int bookingsAdd_User(FILE *input, passengers p_array[], int p_dim,
		flights f_array[], int f_dim) {

	char username[LEN], passport[PASSPORT];

	int passenger_index = 0, flight_index = 0, flagMatch = 0, flagData = 0,
			flagPrint = 0;

	system("clear");
	printf("\nInsert your username: ");
	scanf("%s", username);			//get username
	while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {//control over username
		printf("\nInvalid username."
				"\nPlease, insert a valid one: ");
		scanf("%s", username);
	}

	for (int i = 0; i < p_dim; i++) {		//get passenger index
		if (strcasecmp(p_array[i].username, username) == 0) {
			passenger_index = i;
		}
	}

	printf("\n\nInsert your passport ID: ");
	scanf("%s", passport);		//get passport
	while ((strlen(passport) > PASSPORT_LEN)
			|| (strlen(passport) < PASSPORT_LEN)) {		//control over passport
		printf("\nInvalid passport ID."
				"\nPlease, insert a valid one: ");
		scanf("%s", passport);
	}

	if (strcasecmp(p_array[passenger_index].passport_number, passport) == 0) {
		flagMatch = 1;		//if match found
	}

	if (flagMatch == 1) {		//if match found

		printf("\n\nAvailable flights: \n");

		for (int j = 0; j < f_dim; j++) {		//print available flights
			printf("%d° flight - ID: %s --- %s-%s\n", j, f_array[j].id,
					f_array[j].departure, f_array[j].arrival);

		}

		printf("\n\nInsert the flight number to book: ");
		scanf("%d", &flight_index);		//get flight index
		while (flight_index > f_dim - 1) {		//control over flight index
			printf("\nInvalid flight number."
					"\nPlease, insert a valid one: ");
			scanf("%d", &flight_index);
		}

		system("clear");
		printf("\n\nYou selected the %d° flight.\n"
				"Press ENTER key to confirm booking.", flight_index);
		getchar();
		getchar();

		//tempporary storage to avoid segmentation faults errors
		char user[LEN], fly_id[LEN], book_id[LEN], arrival[LEN], departure[LEN];
		int board = 0, check = 0;

		strcpy(user, p_array[passenger_index].username);
		strcpy(fly_id, f_array[flight_index].id);

		//booking_id
		strncpy(book_id, p_array[passenger_index].username, 2);
		strncat(book_id, f_array[flight_index].id, 3);
		strncat(book_id, f_array[flight_index].company, 2);

		strcpy(arrival, f_array[flight_index].arrival);
		strcpy(departure, f_array[flight_index].departure);

		flagData = 1;

		input = fopen("bookings.csv", "a");		//point to file

		if ((input = fopen("bookings.csv", "a")) == NULL) {	//check over file open
			printf("\n\nFile not found."
					"\nI'll create one."
					"\nPress ENTER key to continue.");
			getchar();
			getchar();
		} else {
			fprintf(input, "%s,%s,%s,%s,%s,%d,%d\n", user, fly_id, book_id,	//print data
					arrival, departure, board, check);
			flagPrint = 1;
		}
		rewind(input);		//rewind stream
		fclose(input);		//close file
	}

	//flag check
	int flag = flagChecker(flagMatch, flagData);
	flag = flagChecker(flag, flagPrint);

	return flag;
}

/**
 *
 * Pre-condition:
 * 		Files bookings.csv, passengers.csv and flights.csv must exists, in fact the number of rows
 * 		will match the arrays dimensions.
 *
 * 	Post-condition:
 * 		The function/method called by the menu will be called
 * 		and the return value used to determine if the operation is
 * 		successful or not.
 *
 */
void bookingsMenu_User(void) {
	FILE *passengersPtr, *flightsPtr, *bookingsPtr;		//pointers

	int menu = 0, n_passengers = 0, n_flights = 0, n_bookings = 0,
			flagLoad_passengers = 0, flagLoad_flights = 0,
			flagLoad_bookings = 0, flagLoad = 0, flag2 = 0, flag = 0;

	while (menu != 5) {
		fflush(stdin);
		fflush(stdout);
		passengersPtr = fopen("passengers.csv", "r");//pointing to passengers file
		flightsPtr = fopen("flights.csv", "r");		//pointing to flights file
		bookingsPtr = fopen("bookings.csv", "r");	//pointing to bookings file

		if ((passengersPtr = fopen("passengers.csv", "r")) == NULL) { //check passengers.csv
			printf("\nFile passengers.csv not found."
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {

			if ((flightsPtr = fopen("flights.csv", "r")) == NULL) {	//check flights.csv
				printf("\nFile flights.csv not found."
						"\nPress ENTER key to continue.");
				getchar();
				getchar();
			} else {

				if ((bookingsPtr = fopen("bookings.csv", "r")) == NULL) {//check bookings.csv
					printf("\nFile bookings.csv not found."
							"Press ENTER key to continue.");
					getchar();
					getchar();
				} else {
					fflush(stdin);

					n_bookings = rowCount(bookingsPtr, "bookings.csv");	//get number of flights

					bookings booking[n_bookings];//create n_bookings-struct array

					bookingsCleaner(booking, n_bookings);	//empty the array

					n_passengers = rowCount(passengersPtr, "passengers.csv"); //get number of passengers

					passengers passenger[n_passengers];	//create n_passengers-struct array

					n_flights = rowCount(flightsPtr, "flights.csv");//get number of flights

					flights flight[n_flights];	//create n_flights- struct array

					n_bookings = rowCount(bookingsPtr, "bookings.csv");

					flagLoad_passengers = passengersLoad(passengersPtr,
							passenger, n_passengers);		//load passengers

					flagLoad_flights = flightsLoad(flightsPtr, flight,
							n_flights);		//load flights

					flagLoad_bookings = bookingsLoad(bookingsPtr, booking,
							n_bookings);		//load bookings

					flagLoad = flagChecker(flagLoad_passengers,
							flagLoad_flights);//check if passengers and flights are successfully loaded into arrays
					flagLoad = flagChecker(flagLoad, flagLoad_bookings);//check if bookings are successfully loaded

					//rewind streams
					rewind(passengersPtr);
					rewind(flightsPtr);
					rewind(bookingsPtr);

					//close files
					fclose(passengersPtr);
					fclose(flightsPtr);
					fclose(bookingsPtr);

					system("clear");

					printf("\t\t\t---Bookings menu---\n\n"
							"\t(1) Add a booking.\n"
							"\t(2) Edit a booking.\n"
							"\t(3) Delete a booking.\n"
							"\t(4) Do the check-in.\n"
							"\t(5) Return.\n"
							"\n\nSelect an option [1-5]: ");
					scanf("%d", &menu);

					switch (menu) {
					case 1:

						flag2 = bookingsAdd_User(bookingsPtr, passenger,//1 if add successful
								n_passengers, flight, n_flights);

						flag = flagChecker(flagLoad, flag2);//check if load and add returned 1, then flag will be 1

						flagMessage(flag);		//check over flag value

						break;

					case 2:

						flag2 = bookingsEdit(bookingsPtr, booking, n_bookings,//1 if add successful
								flight, n_flights);

						flag = flagChecker(flagLoad, flag2);//check if load and edit returned 1, then flag will be 1

						flagMessage(flag);		//check over flag value

						break;

					case 3:
						flag2 = bookingsDelete(bookingsPtr, booking,//1 if add successful
								n_bookings);
						flag = flagChecker(flagLoad, flag2);//check if load and delete returned 1, then flag will be 1

						flagMessage(flag);		//check over flag value
						break;

					case 4:
						flag2 = checkIn(bookingsPtr, booking, n_bookings,
								flight, n_flights);
						flag = flagChecker(flagLoad, flag2);

						flagMessage(flag);		//check over flag value
						break;
					case 5:	//exit case to prevent the exit clause wrong recoinnaised by the default case
						system("clear");
						printf("Returning...\n\n");
						break;
					default://defensive prog. against non-admitted chars, wrong selection, and symbols
						system("clear");
						getchar();
						printf("\n\nWrong selection."
								"\nPress ENTER key to retry.");
						getchar();
						getchar();
						break;
					}
				}

			}
		}
	}
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		File bookings.csv will contain all the updated data, including
 * 		all the bookings added by the admin.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 *
 */
int bookingsAdd_Admin(FILE *input, passengers p_array[], int p_dim,
		flights f_array[], int f_dim) {

	char username[LEN];

	int passenger_index = 0, flight_index = 0, flagMatch = 0, flagData = 0,
			flagPrint = 0,flag=0;

	system("clear");
	printf("\nInsert a username: ");
	scanf("%s", username);			//get username
	while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {//control over username
		printf("\nInvalid username."
				"\nPlease, insert a valid one: ");
		scanf("%s", username);
	}

	for (int i = 0; i < p_dim; i++) {		//get passenger index
		if (strcasecmp(p_array[i].username, username) == 0) {
			passenger_index = i;
			flagMatch = 1;
		}
	}

	if (flagMatch == 1) {		//if match found

		printf("\n\nAvailable flights: \n");

		for (int j = 0; j < f_dim; j++) {		//print available flights
			printf("%d° flight - ID: %s --- %s-%s\n", j, f_array[j].id,
					f_array[j].departure, f_array[j].arrival);

		}

		printf("\n\nInsert the flight number to book: ");
		scanf("%d", &flight_index);		//get flight index
		while (flight_index > f_dim - 1) {		//control over flight index
			printf("\nInvalid flight number."
					"\nPlease, insert a valid one: ");
			scanf("%d", &flight_index);
		}

		system("clear");
		printf("\n\nYou selected the %d° flight.\n"
				"Press ENTER key to confirm booking.", flight_index);
		getchar();
		getchar();

		//tempporary storage to avoid segmentation faults errors
		char user[LEN], fly_id[LEN], book_id[LEN], arrival[LEN], departure[LEN];
		int board = 0, check = 0;

		strcpy(user, p_array[passenger_index].username);
		strcpy(fly_id, f_array[flight_index].id);

		//booking_id
		strncpy(book_id, p_array[passenger_index].username, 2);
		strncat(book_id, f_array[flight_index].id, 3);
		strncat(book_id, f_array[flight_index].company, 2);

		strcpy(arrival, f_array[flight_index].arrival);
		strcpy(departure, f_array[flight_index].departure);

		flagData = 1;

		input = fopen("bookings.csv", "a");		//point to file

		if ((input = fopen("bookings.csv", "a")) == NULL) {	//check over file open
			printf("\n\nFile not found."
					"\nI'll create one."
					"\nPress ENTER key to continue.");
			getchar();
			getchar();
		} else {
			fprintf(input, "%s,%s,%s,%s,%s,%d,%d\n", user, fly_id, book_id,	//print data
					arrival, departure, board, check);
			flagPrint = 1;
		}
		rewind(input);		//rewind stream
		fclose(input);		//close file
	}

	//flag check
	flag = flagChecker(flagMatch, flagData);
	flag = (flag, flagPrint);

	return flag;
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		File bookings.csv will contain all the updated data, including
 * 		the booking edited by the admin.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 *
 */
int bookingsEdit_Admin(FILE *input, bookings b_array[], int b_dim,
		flights f_array[], int f_dim) {

	char username[LEN];

	int booking_index = 0, flight_index = 0, flagPrint=0;

	system("clear");

	printf("\nInsert a username: ");
	scanf("%s", username);

	for (int i = 0; i < b_dim; i++) {
		if (strcasecmp(b_array[i].username, username) == 0) {
			booking_index = i;
		}
	}

	printf("\nAvailable flights: \n");

	for (int j = 0; j < f_dim; j++) {
		printf("%d° flight - ID: %s --- %s-%s\n", j, f_array[j].id,
				f_array[j].departure, f_array[j].arrival);
	}

	printf("\nSelect a flight: ");
	scanf("%d", &flight_index);

	printf("\n\nYou selected the %d flight."
			"\nPress ENTER key to confirm.", flight_index);
	getchar();
	getchar();

	//clean it first

	memset(b_array[booking_index].booking_id, 0,
			strlen(b_array[booking_index].booking_id));
	memset(b_array[booking_index].arrival, 0,
			strlen(b_array[booking_index].arrival));
	memset(b_array[booking_index].departure, 0,
			strlen(b_array[booking_index].departure));
	memset(b_array[booking_index].fly_id, 0,
			strlen(b_array[booking_index].fly_id));
	b_array[booking_index].check_in = 0;
	b_array[booking_index].boarded = 0;

	strcpy(b_array[booking_index].fly_id, f_array[flight_index].id);
	strcpy(b_array[booking_index].arrival, f_array[flight_index].arrival);
	strcpy(b_array[booking_index].departure, f_array[flight_index].departure);
	strncpy(b_array[booking_index].booking_id, b_array[booking_index].username,
			2);
	strncat(b_array[booking_index].booking_id, f_array[flight_index].id, 3);
	strncat(b_array[booking_index].booking_id, f_array[flight_index].company,
			2);

	int flag = 1;

	input = fopen("bookings.csv", "w");

	if ((input = fopen("bookings.csv", "w")) == NULL) {
		printf("\n\nFile bookings.csv not found."
				"\nI'll create one."
				"\nPress ENTER key to continue.");
		getchar();
		getchar();
	} else {
		flagPrint = bookingsPrinter(input, b_array, b_dim);
	}
	rewind(input);
	fclose(input);

	flag = flagChecker(flag, flagPrint);

	return flag;
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		File bookings.csv will contain all the updated data, minus
 * 		the booking deleted by the admin.
 * 		Flag will be 1 if the operation is successful, else, it will be 0.
 *
 */
int bookingsDelete_Admin(FILE *input, bookings b_array[], int b_dim) {

	char select = 'y', username[LEN];
	int delete_index = 0, flagDelete = 0, flagPrint = 0, flag = 0;

	getchar();
	printf("\n\nDo you want to delete a booking? [y/n]: ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		printf("\nInvalid option."
				"\nPlease, select a valid one: ");
		scanf("%c", &select);
	}

	if (select == 'y') {

		memset(username, 0, strlen(username));	//clean username

		printf("\nInsert a username: ");
		scanf("%s", username);		//get username
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN))

			for (int i = 0; i < b_dim; i++) {
				if (strcasecmp(b_array[i].username, username) == 0) {//check username matching
					delete_index = i;	//set delete index to i-element matched
				}
			}

		for (int j = delete_index; j < b_dim; j++) {//move the next k elements to j-deleted
			int k = j + 1;

			strcpy(b_array[j].arrival, b_array[k].arrival);
			strcpy(b_array[j].departure, b_array[k].departure);
			strcpy(b_array[j].booking_id, b_array[k].booking_id);
			strcpy(b_array[j].fly_id, b_array[k].fly_id);
			strcpy(b_array[j].username, b_array[k].username);
			b_array[j].boarded = b_array[k].boarded;
			b_array[j].check_in = b_array[k].check_in;
			j++;
			flagDelete = 1;			//if delete successful, set flagDelete to 1
		}

		if (flagDelete == 1) {		//if delete successful, open the file
			input = fopen("bookings.csv", "w");	//pointer is pointing to file, opened in write

			if ((input = fopen("bookings.csv", "w")) == NULL) {	//check over file
				printf("\nFile not found.\n"
						"Press ENTER key to continue.");
				getchar();
				getchar();
			} else {
				b_dim = b_dim - 1;//reduce the array dimension because of the deleted element
				flagPrint = bookingsPrinter(input, b_array, b_dim);	//flagPrint will be 1 if print successful
			}
		}

	}
	flag = flagChecker(flagDelete, flagPrint);//flag will be 1 if all the operations are successfull and returned 1

	return flag;
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the array dimension.
 * 		Bookings array must contain data to let the print work.
 *
 * 	Post-condition:
 * 		The function will display to screen the result of
 * 		the search operation.
 *
 */
int bookingsSearch_Username(FILE *input, bookings b_array[], int b_dim) {
	char select = 'y', username[LEN];
	int search_index = 0, flag = 0;

	while (select == 'y') {
		system("clear");
		getchar();
		printf("\n\nDo you want to start a new search? [y/n]: ");
		scanf("%c", &select);
		while (!isalpha(select)) {
			printf("\nInvalid option."
					"\nPlease, select a valid one: ");
			scanf("%c", &select);
		}

		printf("\nInsert username to search by: ");
		scanf("%s", username);		//get username
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {//control over username
			printf("\nInvalid username."
					"Please, insert a valid one: ");
			scanf("%s", username);
		}

		for (int i = 0; i < b_dim; i++) {
			if (strcasecmp(b_array[i].username, username) == 0) {//if match found
				search_index = i;		//set search index to i
				flag = 1;		//set flag to 1
			}
		}

		printf("flight ID: %s\n", b_array[search_index].fly_id);//print flight
		getchar();
		getchar();
	}
	return flag;
}

/**
 *
 * Pre-condition:
 * 		File bookings.csv must exist, in fact the number of rows
 * 		will match the arrays dimensions.
 *
 * 	Post-condition:
 * 		The function/method called by the menu will be called
 * 		and the return value used to determine if the operation is
 * 		successful or not.
 *
 */
void bookingsSearch_Menu(void) {

	FILE *passengersPtr, *flightsPtr, *bookingsPtr;		//pointers

	int n_flights = 0, n_bookings = 0, n_passengers = 0, menu = 0, flagLoad_p =
			0, flagLoad_f = 0, flagLoad_b = 0, flagSearch = 0, flag = 0;

	while (menu != 2) {

		passengersPtr = fopen("passengers.csv", "r");//point to passengers file
		flightsPtr = fopen("flights.csv", "r");		//point to flights file
		bookingsPtr = fopen("bookings.csv", "r");		//point to bookings file

		if ((bookingsPtr = fopen("bookings.csv", "r")) == NULL) {//control over bookings file
			printf("\nFile bookings.csv not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			if ((passengersPtr = fopen("passengers.csv", "r")) == NULL) {//control over passengers file
				printf("\nFile passengers.csv not found."
						"\nPress ENTER key to continue.");
				getchar();
				getchar();
			} else {
				if ((flightsPtr = fopen("flights.csv", "r")) == NULL) {	//control over flights file
					printf("\nFile flights.csv not found.\n"
							"Press ENTER key to continue.");
					getchar();
					getchar();
				} else {

					n_flights = rowCount(flightsPtr, "flights.csv");//calculate number of flights
					n_bookings = rowCount(bookingsPtr, "bookings.csv");	//calculate number of bookings
					n_passengers = rowCount(passengersPtr, "passengers.csv");//calculate number of passengers

					//creating n-dimensions arrays
					passengers passenger[n_passengers];
					bookings booking[n_bookings];
					flights flight[n_flights];

					/**
					 * Loading files into arrays.
					 * 	Return value will be:
					 * 	[1] if load success
					 * 	[0] if load fails
					 */

					flagLoad_p = passengersLoad(passengersPtr, passenger,
							n_passengers);
					flagLoad_f = flightsLoad(flightsPtr, flight, n_flights);
					flagLoad_b = bookingsLoad(bookingsPtr, booking, n_bookings);
					flag = flagChecker(flagLoad_p, flagLoad_f);	//check load (passengers,flights = flag)
					flag = flagChecker(flag, flagLoad_b);//check load (flag, bookings = flag)

					system("clear");

					printf("\n\n\t---Bookings administration menu---"
							"\n\t(1) Search bookings by username."
							"\n\t(2) Return.\n"
							"\n\nSelect an option [1-x]: ");
					scanf("%d", &menu);

					switch (menu) {
					case 1:
						flagSearch = bookingsSearch_Username(bookingsPtr,
								booking,		//return 1 if search completed
								n_bookings);
						flag = flagChecker(flag, flagSearch);//flag will be 1 if flag and flagsearch are 1
						flagMessage(flag);	//output message based on flag value
						break;
					case 2:	//exit case to prevent the exit clause wrong recoinnaised by the default case
						system("clear");
						printf("Returning...\n\n");
						break;
					default://defensive prog. against non-admitted chars, wrong selection, and symbols
						system("clear");
						getchar();
						printf("\n\nWrong selection."
								"\nPress ENTER key to retry.");
						getchar();
						getchar();
						break;
					}
				}
			}
		}
	}
}

/**
 *
 * Pre-condition:
 * 		Files bookings.csv, passengers.csv and flights.csv must exists, in fact the number of rows
 * 		will match the arrays dimensions.
 *
 * 	Post-condition:
 * 		The function/method called by the menu will be called
 * 		and the return value used to determine if the operation is
 * 		successful or not.
 *
 */
void bookingsMenu_Admin(void) {
	FILE *passengersPtr, *flightsPtr, *bookingsPtr, *binaryPtr;		//pointers

	int menu = 0, n_passengers = 0, n_flights = 0, n_bookings = 0,
			flagLoad_passengers = 0, flagLoad_flights = 0,
			flagLoad_bookings = 0, flagLoad = 0, flag2 = 0, flag = 0;

	long int offset = 0;

	while (menu != 7) {
		fflush(stdin);
		fflush(stdout);
		passengersPtr = fopen("passengers.csv", "r");//point to passengers file - read mode
		flightsPtr = fopen("flights.csv", "r");	//point to flights file - read mode
		bookingsPtr = fopen("bookings.csv", "r");//point to bookings file - read mode

		if ((passengersPtr = fopen("passengers.csv", "r")) == NULL) { //check passengers.csv
			printf("\nFile passengers.csv not found."
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			n_passengers = rowCount(passengersPtr, "passengers.csv"); //get passengers number

			passengers passenger[n_passengers];	//create n_passengers-struct array

			if ((flightsPtr = fopen("flights.csv", "r")) == NULL) {	//check flights.csv
				printf("\nFile flights.csv not found."
						"\nPress ENTER key to continue.");
				getchar();
				getchar();
			} else {

				n_flights = rowCount(flightsPtr, "flights.csv");//get flights number

				flights flight[n_flights];		//create n_flights- struct array

				if ((bookingsPtr = fopen("bookings.csv", "r")) == NULL) {//check bookings.csv
					printf("\nFile bookings.csv not found."
							"Press ENTER key to continue.");
					getchar();
					getchar();
				} else {

					n_bookings = rowCount(bookingsPtr, "bookings.csv");	//get bookings number

					bookings booking[n_bookings];//create n_bookings-struct array

					/**
					 * Loading files into arrays.
					 * 	Return value will be:
					 * 	[1] if load success
					 * 	[0] if load fails
					 */
					flagLoad_passengers = passengersLoad(passengersPtr,
							passenger, n_passengers);

					flagLoad_flights = flightsLoad(flightsPtr, flight,
							n_flights);

					flagLoad_bookings = bookingsLoad(bookingsPtr, booking,
							n_bookings);

					flagLoad = flagChecker(flagLoad_passengers,
							flagLoad_flights);//check if passengers and flights are successfully loaded into arrays
					flagLoad = flagChecker(flagLoad, flagLoad_bookings);//check if bookings are successfully loaded

					//rewind streams
					rewind(passengersPtr);
					rewind(flightsPtr);
					rewind(bookingsPtr);

					//close files
					fclose(passengersPtr);
					fclose(flightsPtr);
					fclose(bookingsPtr);

					system("clear");

					printf("\t\t\t---Bookings administration---\n\n"
							"\t(1) Add a booking.\n"
							"\t(2) Edit a booking.\n"
							"\t(3) Delete a booking.\n"
							"\t(4) Booking search menù\n"
							"\t(5) Boarding.\n"
							"\t(6) Show non-boarded passengers.\n"
							"\t(7) Return."
							"\n\nSelect an option [1-7]: ");
					scanf("%d", &menu);

					switch (menu) {
					case 1:

						flag2 = bookingsAdd_Admin(bookingsPtr,//return 1 if success, 0 if fail
								booking, n_bookings, flight, n_flights);

						flag = flagChecker(flagLoad, flag2);

						flagMessage(flag);	//check over flag value
						break;

					case 2:

						flag2 = bookingsEdit_Admin(bookingsPtr,	//return 1 if success, 0 if fail
								booking, n_bookings, flight, n_flights);

						flag = flagChecker(flagLoad, flag2);

						flagMessage(flag);	//check over flag value

						break;

					case 3:
						flag2 = bookingsDelete_Admin(bookingsPtr, booking,//return 1 if success, 0 if fail
								n_bookings);
						flag = flagChecker(flagLoad, flag2);

						flagMessage(flag);	//check over flag value
						break;
					case 4:
						bookingsSearch_Menu();
						break;
					case 5:
						binaryPtr = fopen("boarding.dat", "wb");

						if ((binaryPtr = fopen("boarding.dat", "wb")) == NULL) {
							printf("\n\nFile not found."
									"\nPress ENTER key to continue.");
							getchar();
							getchar();
						} else {
							boarding(binaryPtr, passenger, n_passengers,
									booking, n_bookings, &offset);
						}
						//printf("%lu", offset);
						break;
					case 6:
						nonboarded(booking, n_bookings);
						printf("\n\nOperation successful."
								"\nPress ENTER key to continue.");
						getchar();
						getchar();
						break;
					case 7:
						system("clear");//exit case to prevent the exit clause wrong recoinnaised by the default case
						printf("Returning...\n\n");
						break;
					default://defensive prog. against non-admitted chars, wrong selection, and symbols
						system("clear");
						getchar();
						printf("\n\nWrong selection."
								"\nPress ENTER key to retry.");
						getchar();
						getchar();
						break;
					}
				}
			}
		}
	}
}

