/*
 * main.c
 *
 *  Created on: 20 mag 2019
 *      Author: Lorenzo Baldari
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

#include "utility.h"
#include "passengers.h"
#include "flights.h"
#include "bookings.h"

int main(void) {
	int menu = 0;
	while (menu != 5) {

		system("clear");

		printf("\t\t---Bari airport---\n"
				"\t(1) User menu.\n"
				"\t(2) Passengers administration.\n"
				"\t(3) Flights administration.\n"
				"\t(4) Bookings administration.\n"
				"\t(5) Exit."
				"\n\n\nEnter an option [1-5]: ");
		scanf("%d", &menu);

		switch (menu) {
		case 1:		//go to passengers menu
			passengersMenu();
			break;
		case 2:		//go to passengers administration menu
			administratorMenu();
			break;
		case 3:		//go to flights administration	menu
			flightsMenu_AdministratorOnly();
			break;
		case 4:		//go to bookings administration menu
			bookingsMenu_Admin();
			break;
		case 5:		//exit case to prevent the exit clause wrong recoinnaised by the default case
			system("clear");
			printf("\nGoodbye!\n\n\n");
			exit(0);
		default:		//defensive prog. against non-admitted chars, wrong selection, and symbols
			system("clear");
			getchar();
			printf("\n\nWrong selection."
					"\nPress ENTER key to retry.");
			getchar();
			getchar();
			break;
		}
	}
}

