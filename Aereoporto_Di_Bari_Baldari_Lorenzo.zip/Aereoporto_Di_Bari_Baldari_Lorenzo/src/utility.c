#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 *
 * Pre-condition: The input flag (x)
 * can be only 0 or 1.
 *
 * Post-condition:
 * 		if 0: output an error message;
 * 		if 1: output a success message.
 *
 */

void flagMessage(int x) {
	if (x == 1) {
		printf("\n\nOperation successful."
				"\nPress ENTER key to continue.");
		getchar();
		getchar();
	} else if (x == 0) {
		printf("\n\nOperation aborted."
				"\nPress ENTER key to continue");
		getchar();
		getchar();
	}
}

/**
 *
 * Pre-condition:
 * 	The input file must exists, and it have
 * 	to match the file_name.
 *
 * 	Post-condition:
 * 		The count will contain the rows number
 * 		found in file.
 *
 */

int rowCount(FILE *input, char *file_name) {
	char c; //to store a character read from file

	int count = 0;	//counter

	if ((input = fopen(file_name, "r")) == NULL) {
		printf("The file doesn't exist.");
	} else {
		for (c = getc(input); c != EOF; c = getc(input))//get character util EOF
			if (c == '\n') // Increment count if this character is newline
				count = count + 1;	//counter to get rows number.
	}
	fclose(input);	//close file
	return count;
}


/**
 * Pre-condition:
 * 	Both input flags (x,y) can be only 1 or 0.
 *
 * 	Post-condition:
 * 		1 AND 1 | 1
 * 		1 AND 0 | 0
 * 		0 AND 0 | 0
 * 		0 AND 0 | 0
 */
int flagChecker(int x, int y) {
	int flag = 0;
	if ((x == 1) && (y == 1)) {
		flag = 1;
	}
	return flag;
}
