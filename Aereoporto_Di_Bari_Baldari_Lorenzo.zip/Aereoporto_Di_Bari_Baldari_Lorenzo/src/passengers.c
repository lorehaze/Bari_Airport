/*
 * passengers.c
 *
 *  Created on: 20 mag 2019
 *      Author: lorenzo
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 * Max admissible value for string lenght.
 */
#define LEN 20

/**
 * Max admissible  value for passport ID.
 */
#define PASSPORT 10

/**
 * Max and min value for passport ID.
 * Used for defensive programmation scopes.
 */
#define MAXMINPASSPORT 9

/**
 * Max and min value for strings.
 * Used for defensive programmation scopes.
 */
#define MAX_LEN 19
#define MIN_LEN 3

/**
 * Min value for sub-string search.
 * Used for defensive programmation scopes.
 */
#define MIN_SUBSEARCH 1

/**
 * 	Date struct.
 * 	Defined to create day/month/year structure.
 */
typedef struct date {

	int day, month, year;

} date;

/**
 * Passengers struct.
 * Defined to assign parameters to
 * passengers.
 */
typedef struct passengers {

	char name[LEN], surname[LEN], username[LEN];

	date birth_date, signup_date;

	char passport_number[PASSPORT];

} passengers;


/**
 *Pre-conditions:
 *	Input file, passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersLoad(FILE *input, passengers array[], int x) { //load file into array
	int flag = 0;
	for (int i = 0; i < x; i++) {
		fscanf(input, "%[^,],%[^,],%[^,],%[^,],%d,%d,%d,%d,%d,%d\n",
				array[i].name, array[i].surname, array[i].username,
				array[i].passport_number, &array[i].birth_date.day,
				&array[i].birth_date.month, &array[i].birth_date.year,
				&array[i].signup_date.day, &array[i].signup_date.month,
				&array[i].signup_date.year);
		flag = 1;		//if success, flag will be 1
	}
	rewind(input);		//stream rewind
	fclose(input);		//close file
	return flag;
}

/**
 *Pre-conditions:
 *	Input file, passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersPrinter(FILE *input, passengers array[], int x) {	//print passengers data into passengers.csv
	int flag = 0;
	for (int i = 0; i < x; i++) {
		fprintf(input, "%s,%s,%s,%s,%d,%d,%d,%d,%d,%d\n", array[i].name,
				array[i].surname, array[i].username, array[i].passport_number,
				array[i].birth_date.day, array[i].birth_date.month,
				array[i].birth_date.year, array[i].signup_date.day,
				array[i].signup_date.month, array[i].signup_date.year);
		flag = 1;		//if success, flag will be 1
	}
	rewind(input);		//stream rewind
	fclose(input);		//close file
	return flag;
}

/**
 *Pre-conditions:
 *	Input file must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersAdd(FILE *input) {
	/**
	 * Add passengers.
	 * 	Return:
	 * 	[1] if success;
	 * 	[0] if failed.
	 */
	int flag = 0, flag2 = 0, flag3 = 0, x = 0;

	system("clear");
	printf("How many passengers do you want to add? ");
	scanf("%d", &x);		//passengers number
	while (x < 0) {		//control over passengers
		printf("\n\nInvalid number.\n"
				"Please, insert a valid one: ");
		scanf("%d", &x);
	}

	if (x > 0) {

		passengers array[x];		//x-array passengers

		input = fopen("passengers.csv", "a");//pointer to file passengers.csv -- appening mode

		if ((input = fopen("passengers.csv", "a")) == NULL) {//control over opening
			system("clear");
			printf("File not found.");
		} else {
			for (int i = 0; i < x; i++) {
				system("clear");

				printf("%d° passenger.\n", i);

				printf("\nInsert name: ");		//get name
				scanf("%s", array[i].name);
				while ((strlen(array[i].name) < MIN_LEN)
						|| (strlen(array[i].name) > MAX_LEN)) {		//get name
					printf("\nInvalid name."
							"\nPlease, insert a name: ");
					scanf("%s", array[i].name);
				}

				printf("\nInsert surname: ");
				scanf("%s", array[i].surname);
				while ((strlen(array[i].surname) < MIN_LEN)
						|| (strlen(array[i].surname) > MAX_LEN)) {	//get surname
					printf("\nInvalid surname.\n"
							"Please, insert a valid surname: ");
					scanf("%s", array[i].surname);
				}

				printf("\nInsert username: ");
				scanf("%s", array[i].username);
				while ((strlen(array[i].username) < MIN_LEN)
						|| (strlen(array[i].username) > MAX_LEN)) {
					printf("\nInvalid username.\n"
							"Please, insert a valid username: ");
					scanf("%s", array[i].username);
				}

				printf("\nInsert passport number (9 char): ");
				scanf("%s", array[i].passport_number);
				while ((strlen(array[i].passport_number) < 9)
						|| (strlen(array[i].passport_number) > 9)) {
					printf("\nInvalid passport number.\n"
							"\nPlease, insert a valid passport number: ");
					scanf("%s", array[i].passport_number);
				}

				/**
				 * 	BIRTHDAY *
				 **/
				printf("\nInsert the birth day: ");	//get b.day
				scanf("%d", &array[i].birth_date.day);

				if (array[i].birth_date.day < 1
						|| array[i].birth_date.day > 31) {	//day check
					while (array[i].birth_date.day == 0
							|| array[i].birth_date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid birth day: ");
						scanf("%d", &array[i].birth_date.day);
					}
				}

				printf("\nInsert the birth month: ");	//get birth month
				scanf("%d", &array[i].birth_date.month);

				if (array[i].birth_date.month == 0
						|| array[i].birth_date.month > 12) {	//check month
					while (array[i].birth_date.month == 0
							|| array[i].birth_date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a valid month: ");
						scanf("%d", &array[i].birth_date.month);
					}
				}

				if (array[i].birth_date.day > 28) {	//check february
					while (array[i].birth_date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid birth month: ");
						scanf("%d", &array[i].birth_date.month);
					}
				}

				if (array[i].birth_date.day == 31) {	//check month
					while (array[i].birth_date.month == 4
							|| array[i].birth_date.month == 6
							|| array[i].birth_date.month == 9
							|| array[i].birth_date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid birth month: ");
						scanf("%d", &array[i].birth_date.month);
					}
				}

				printf("\nInsert birth year: ");		//get birth year
				scanf("%d", &array[i].birth_date.year);
				if (array[i].birth_date.year < 1920
						|| array[i].birth_date.year > 2019) {
					printf("\nInvalid year.\n"
							"Please, insert a valid birth year: ");
					scanf("%d", &array[i].birth_date.year);
				}

				/**
				 * SIGN-UP *
				 **/

				printf("\nInsert the signup day: ");	//get signup day
				scanf("%d", &array[i].signup_date.day);

				if (array[i].signup_date.day < 1
						|| array[i].signup_date.day > 31) {	//day check
					while (array[i].signup_date.day == 0
							|| array[i].signup_date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid signup day: ");
						scanf("%d", &array[i].signup_date.day);
					}
				}

				printf("\nInsert the signup month: ");	//get signup month
				scanf("%d", &array[i].signup_date.month);

				if (array[i].signup_date.month == 0
						|| array[i].signup_date.month > 12) {	//check month
					while (array[i].signup_date.month == 0
							|| array[i].signup_date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a signup month: ");
						scanf("%d", &array[i].signup_date.month);
					}
				}

				if (array[i].signup_date.day > 28) {	//check february
					while (array[i].signup_date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid signup month: ");
						scanf("%d", &array[i].signup_date.month);
					}
				}

				if (array[i].signup_date.day == 31) {	//check month
					while (array[i].signup_date.month == 4
							|| array[i].signup_date.month == 6
							|| array[i].signup_date.month == 9
							|| array[i].signup_date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid signup month: ");
						scanf("%d", &array[i].signup_date.month);
					}
				}

				printf("\nInsert signup year: ");		//get signup year
				scanf("%d", &array[i].signup_date.year);
				if ((array[i].signup_date.year < 1920
						|| array[i].signup_date.year > 2019)
						&& (array[i].signup_date.year
								>= array[i].birth_date.year)) {
					while ((array[i].signup_date.year < 1920
							|| array[i].signup_date.year > 2019)
							&& (array[i].signup_date.year
									>= array[i].birth_date.year)) {
						printf("\nInvalid year.\n"
								"Please, insert a valid signup year: ");
						scanf("%d", &array[i].signup_date.year);
					}
				}
			}
		}
		flag2 = 1;		//set flag2 to 1 if success
		flag3 = passengersPrinter(input, array, x);	//return 1 if print successful
		flag = flagChecker(flag2, flag3);		//if 1 and 1 = 1
	}


	return flag;
}

/**
 *Pre-conditions:
 *	Input file, passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersEditor(FILE *input, passengers array[], int x) {
	/**
	 * Edit passenger.
	 *
	 * 	Return:
	 * 	[1] if success;
	 * 	[0] if fails;
	 */
	system("clear");
	char select = 'n', username[LEN], passport[PASSPORT];

	int edited = 0, flag = 0, flag2 = 0, flag3 = 0;

	getchar();
	printf("Do you want to edit your data? [y/n]: ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		printf("\nInvalid selection."
				"Please, retry: ");
		scanf("%c", &select);
	}

	if (select == 'y') {
		printf("\nInsert username: ");
		scanf("%s", username);		//get name
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {	//control over name
			printf("\nInvalid name."
					"Please, insert a valid username: ");
			scanf("%s", username);
		};

		printf("\nInsert passport number (9 char): ");
		scanf("%s", passport);			//get passport
		while ((strlen(passport) < 9) || (strlen(passport) > 9)) { //control over passport
			printf("\nInvalid passport number.\n"
					"Please, insert a valid passport number: ");
			scanf("%s", passport);
		}

		for (int i = 0; i < x; i++) {
			if (strcasecmp(array[i].username, username) == 0 //verify and login
			&& strcasecmp(array[i].passport_number, passport) == 0) {
				system("clear");
				edited = i;

				printf("%d° passenger.\n"
						"\n\nPress ENTER key to edit a passenger.", i);

				printf("\nInsert name: ");
				scanf("%s", array[edited].name);		//get name
				while ((strlen(array[edited].name) < MIN_LEN)		//control over name
				|| (strlen(array[edited].name) > MAX_LEN)) {
					printf("\nInvalid name."
							"Please, insert a name: ");
					scanf("%s", array[edited].name);
				}

				printf("\nInsert surname: ");
				scanf("%s", array[edited].surname);		//get surname
				while ((strlen(array[edited].surname) < MIN_LEN)
						|| (strlen(array[edited].surname) > MAX_LEN)) {//control over surname
					printf("\nInvalid name.\n"
							"Please, insert a valid surname: ");
					scanf("%s", array[edited].surname);
				}

				printf("\nInsert username: ");
				scanf("%s", array[edited].username);		//get username
				while ((strlen(array[edited].username) < MIN_LEN)	//control over username
				|| (strlen(array[edited].username) > MAX_LEN)) {
					if (strlen(array[edited].username) < MIN_LEN) {
						scanf("%s", array[edited].username);
					}
				}

				printf("\nInsert passport number (9 char): ");
				scanf("%s", array[edited].passport_number);		//get passport
				while ((strlen(array[edited].passport_number) < 9)//control over passport
				|| (strlen(array[edited].passport_number) > 9)) {
					printf("\nInvalid passport number.\n"
							"Please, insert a valid passport number: ");
					scanf("%s", array[edited].passport_number);
				}

				/**
				 * 	BIRTHDAY *
				 **/
				printf("\nInsert the birth day: ");	//get b.day
				scanf("%d", &array[edited].birth_date.day);

				if (array[edited].birth_date.day < 1
						|| array[edited].birth_date.day > 31) {	//day check
					while (array[edited].birth_date.day == 0
							|| array[edited].birth_date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid birth day: ");
						scanf("%d", &array[edited].birth_date.day);
					}
				}

				printf("\nInsert the birth month: ");	//get birth month
				scanf("%d", &array[edited].birth_date.month);

				if (array[edited].birth_date.month == 0
						|| array[edited].birth_date.month > 12) {//check month
					while (array[edited].birth_date.month == 0
							|| array[edited].birth_date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a valid month: ");
						scanf("%d", &array[edited].birth_date.month);
					}
				}

				if (array[edited].birth_date.day > 28) {	//check february
					while (array[edited].birth_date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid birth month: ");
						scanf("%d", &array[edited].birth_date.month);
					}
				}

				if (array[edited].birth_date.day == 31) {	//check month
					while (array[edited].birth_date.month == 4
							|| array[edited].birth_date.month == 6
							|| array[edited].birth_date.month == 9
							|| array[edited].birth_date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid birth month: ");
						scanf("%d", &array[edited].birth_date.month);
					}
				}

				printf("\nInsert birth year: ");		//get birth year
				scanf("%d", &array[edited].birth_date.year);
				if (array[edited].birth_date.year < 1920
						|| array[edited].birth_date.year > 2019) {
					printf("\nInvalid year.\n"
							"Please, insert a valid birth year: ");
					scanf("%d", &array[edited].birth_date.year);
				}

				/**
				 * SIGN-UP *
				 **/

				printf("\nInsert the signup day: ");	//get signup day
				scanf("%d", &array[edited].signup_date.day);

				if (array[edited].signup_date.day < 1
						|| array[edited].signup_date.day > 31) {	//day check
					while (array[edited].signup_date.day == 0
							|| array[edited].signup_date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid signup day: ");
						scanf("%d", &array[edited].signup_date.day);
					}
				}

				printf("\nInsert the signup month: ");	//get signup month
				scanf("%d", &array[edited].signup_date.month);

				if (array[edited].signup_date.month == 0
						|| array[edited].signup_date.month > 12) {//check month
					while (array[edited].signup_date.month == 0
							|| array[edited].signup_date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a signup month: ");
						scanf("%d", &array[edited].signup_date.month);
					}
				}

				if (array[edited].signup_date.day > 28) {	//check february
					while (array[edited].signup_date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid signup month: ");
						scanf("%d", &array[edited].signup_date.month);
					}
				}

				if (array[edited].signup_date.day == 31) {	//check month
					while (array[edited].signup_date.month == 4
							|| array[edited].signup_date.month == 6
							|| array[edited].signup_date.month == 9
							|| array[edited].signup_date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid signup month: ");
						scanf("%d", &array[edited].signup_date.month);
					}
				}

				printf("\nInsert signup year: ");		//get signup year
				scanf("%d", &array[edited].signup_date.year);
				if ((array[edited].signup_date.year < 1920
						|| array[edited].signup_date.year > 2019)
						&& (array[edited].signup_date.year
								>= array[edited].birth_date.year)) {
					while ((array[edited].signup_date.year < 1920
							|| array[edited].signup_date.year > 2019)
							&& (array[edited].signup_date.year
									>= array[edited].birth_date.year)) {
						printf("\nInvalid year.\n"
								"Please, insert a valid signup year: ");
						scanf("%d", &array[edited].signup_date.year);
					}
				}
				flag2 = 1;		//if success, set flag2 to 1
			}
		}

	}
	input = fopen("passengers.csv", "w");		//open file in write mode

	if (flag2 == 1) {
		if ((input = fopen("passengers.csv", "w")) == NULL) {//control over open
			printf("File not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flag3 = passengersPrinter(input, array, x);		//1 if success
		}
	}

	flag = flagChecker(flag2, flag3);		//1 if 1 and 1

	rewind(input);		//rewind stream
	fclose(input);		//close file
	return flag;
}

/**
 *Pre-conditions:
 *	Input file, passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersEditor_Admin(FILE *input, passengers array[], int x) {

	/**
	 * (Admin) Edit passenger.
	 *
	 * 	Return:
	 * 	[1] if success;
	 * 	[0] if fails;
	 */

	system("clear");
	char select = 'n', username[LEN];

	int edited = 0, flag = 0, flag2 = 0, flag3 = 0;

	getchar();
	printf("Do you want to edit an account data? [y/n]:  ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		printf("\nInvalid selection."
				"Please, retry: ");
		scanf("%c", &select);
	}

	if (select == 'y') {
		printf("\nInsert username: ");
		scanf("%s", username);
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {	//get name
			printf("\nInvalid name."
					"Please, insert a valid username: ");
			scanf("%s", username);
		};

		for (int i = 0; i < x; i++) {
			if (strcasecmp(array[i].username, username) == 0) {	//username check
				system("clear");
				edited = i;

				printf("%d° passenger.\n"
						"\n\nPress ENTER key to add passenger.", i);

				getchar();
				getchar();

				printf("\nInsert name: ");
				scanf("%s", array[edited].name);
				while ((strlen(array[edited].name) < MIN_LEN)
						|| (strlen(array[edited].name) > MAX_LEN)) {		//get name
					printf("\nInvalid name."
							"Please, insert a name: ");
					scanf("%s", array[edited].name);
				}

				printf("\nInsert surname: ");
				scanf("%s", array[edited].surname);
				while ((strlen(array[edited].surname) < MIN_LEN)
						|| (strlen(array[edited].surname) > MAX_LEN)) {//get surname
					printf("\nInvalid name.\n"
							"Please, insert a valid surname: ");
					scanf("%s", array[edited].surname);
				}

				printf("\nInsert username: ");
				scanf("%s", array[edited].username);
				while ((strlen(array[edited].username) < MIN_LEN)
						|| (strlen(array[edited].username) > MAX_LEN)) {
					if (strlen(array[edited].username) < MIN_LEN) {
						scanf("%s", array[edited].username);
					}
				}

				printf("\nInsert passport number (9 char): ");
				scanf("%s", array[edited].passport_number);
				while ((strlen(array[edited].passport_number) < 9)
						|| (strlen(array[edited].passport_number) > 9)) {
					printf("\nInvalid passport number.\n"
							"Please, insert a valid passport number: ");
					scanf("%s", array[edited].passport_number);
				}

				/**
				 * 	BIRTHDAY *
				 **/
				printf("\nInsert the birth day: ");	//get b.day
				scanf("%d", &array[edited].birth_date.day);

				if (array[edited].birth_date.day < 1
						|| array[edited].birth_date.day > 31) {	//day check
					while (array[edited].birth_date.day == 0
							|| array[edited].birth_date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid birth day: ");
						scanf("%d", &array[edited].birth_date.day);
					}
				}

				printf("\nInsert the birth month: ");	//get birth month
				scanf("%d", &array[edited].birth_date.month);

				if (array[edited].birth_date.month == 0
						|| array[edited].birth_date.month > 12) {//check month
					while (array[edited].birth_date.month == 0
							|| array[edited].birth_date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a valid month: ");
						scanf("%d", &array[edited].birth_date.month);
					}
				}

				if (array[edited].birth_date.day > 28) {	//check february
					while (array[edited].birth_date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid birth month: ");
						scanf("%d", &array[edited].birth_date.month);
					}
				}

				if (array[edited].birth_date.day == 31) {	//check month
					while (array[edited].birth_date.month == 4
							|| array[edited].birth_date.month == 6
							|| array[edited].birth_date.month == 9
							|| array[edited].birth_date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid birth month: ");
						scanf("%d", &array[edited].birth_date.month);
					}
				}

				printf("\nInsert birth year: ");		//get birth year
				scanf("%d", &array[edited].birth_date.year);
				if (array[edited].birth_date.year < 1920
						|| array[edited].birth_date.year > 2019) {
					printf("\nInvalid year.\n"
							"Please, insert a valid birth year: ");
					scanf("%d", &array[edited].birth_date.year);
				}

				/**
				 * SIGN-UP *
				 **/

				printf("\nInsert the signup day: ");	//get signup day
				scanf("%d", &array[edited].signup_date.day);

				if (array[edited].signup_date.day < 1
						|| array[edited].signup_date.day > 31) {	//day check
					while (array[edited].signup_date.day == 0
							|| array[edited].signup_date.day > 31) {
						printf("\nInvalid day.\n"
								"Please, insert a valid signup day: ");
						scanf("%d", &array[edited].signup_date.day);
					}
				}

				printf("\nInsert the signup month: ");	//get signup month
				scanf("%d", &array[edited].signup_date.month);

				if (array[edited].signup_date.month == 0
						|| array[edited].signup_date.month > 12) {//check month
					while (array[edited].signup_date.month == 0
							|| array[edited].signup_date.month > 12) {
						printf("\nInvalid month."
								"\nPlease, insert a signup month: ");
						scanf("%d", &array[edited].signup_date.month);
					}
				}

				if (array[edited].signup_date.day > 28) {	//check february
					while (array[edited].signup_date.month == 2) {
						printf("\nInvalid month."
								"\nPlease, Insert a valid signup month: ");
						scanf("%d", &array[edited].signup_date.month);
					}
				}

				if (array[edited].signup_date.day == 31) {	//check month
					while (array[edited].signup_date.month == 4
							|| array[edited].signup_date.month == 6
							|| array[edited].signup_date.month == 9
							|| array[edited].signup_date.month == 11) {
						printf("\nInvalid month."
								"\nPlease, insert a valid signup month: ");
						scanf("%d", &array[edited].signup_date.month);
					}
				}

				printf("\nInsert signup year: ");		//get signup year
				scanf("%d", &array[edited].signup_date.year);
				if ((array[edited].signup_date.year < 1920
						|| array[edited].signup_date.year > 2019)
						&& (array[edited].signup_date.year
								>= array[edited].birth_date.year)) {
					while ((array[edited].signup_date.year < 1920
							|| array[edited].signup_date.year > 2019)
							&& (array[edited].signup_date.year
									>= array[edited].birth_date.year)) {
						printf("\nInvalid year.\n"
								"Please, insert a valid signup year: ");
						scanf("%d", &array[edited].signup_date.year);
					}
				}
				flag2 = 1;		//if success, set flag2 to 1
			}
		}
	}
	if (flag2 == 1) {//if modify is success, start opening first, then writing

		input = fopen("passengers.csv", "r+");//open passengers.csv in r+ to edit

		if ((input = fopen("passengers.csv", "r+")) == NULL) {	//check opening
			printf("File not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flag3 = passengersPrinter(input, array, x);	//flag=1 if print success
		}
	}

	flag = flagChecker(flag2, flag3);	// flag2 and flag3 = 1 if both succeded

	rewind(input);		//stream rewind
	fclose(input);		//close file
	return flag;
}

/**
 *Pre-conditions:
 *	Input file, passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersDeleter(FILE *input, passengers array[], int x) {

	/**
	 * Passengers delete.
	 *
	 * Return:
	 *
	 * [1] if success
	 * [0] if failed
	 */

	int flag = 0, flag1 = 0, flag2 = 0, deleted = 0;
	char username[LEN], passport[LEN], select = 'y';

	system("clear");
	getchar();
	printf("Do you want to delete your account? [y/n]: ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		getchar();
		printf("\nInvalid option."
				"Please, retry: ");
		scanf("%c", &select);
	}

	if (select == 'y') {

		printf("\n\n\nPlease, log-in."
				"\nPress ENTER key to continue.");

		getchar();
		getchar();

		printf("\nInsert username: ");
		scanf("%s", username);		//get username
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {	//control over username
			printf("\n\nInvalid username."
					"\nPlease, insert a valid one: ");
			scanf("%s", username);
		}

		printf("\nInsert passport number (9 char): ");
		scanf("%s", passport);		//get passport
		while ((strlen(passport) < 9) || (strlen(passport) > 9)) {//control over passport
			printf("\nInvalid passport number.\n"
					"Please, insert a valid passport number: ");
			scanf("%s", passport);
		}

		for (int i = 0; i < x; i++) {
			if (strcasecmp(array[i].username, username) == 0	//check matching
			&& strcasecmp(array[i].passport_number, passport) == 0) {
				deleted = i;		//passengers index

				printf("\nLogin success.\n"
						"Press ENTER to delete your account.");
				getchar();
				getchar();

				for (int i = deleted; i < x; i++) {	//copy next elements starting by deleted position
					int j = i + 1;
					strcpy(array[i].name, array[j].name);
					strcpy(array[i].surname, array[j].surname);
					strcpy(array[i].username, array[j].username);
					strcpy(array[i].passport_number, array[j].passport_number);
					array[i].birth_date.day = array[j].birth_date.month;
					array[i].birth_date.month = array[j].birth_date.month;
					array[i].birth_date.year = array[j].birth_date.year;
					array[i].signup_date.day = array[j].signup_date.day;
					array[i].signup_date.month = array[j].signup_date.month;
					array[i].signup_date.year = array[j].signup_date.year;
					j++;
					flag2 = 1;		//set flag2 to 1 if delete successful
				}

				flag1 = 1;		//set flag to 1 if success
			}
		}

		flag = flagChecker(flag1, flag2);//if flag1 and flag2 = 1, they'll return 1

			input = fopen("passengers.csv", "w");//open passengers.csv in write mode, deleting the existing content

			if ((input = fopen("passengers.csv", "w")) == NULL) {//check over opening
				printf("\n\nFile passengers.csv not found."
						"\nPress ENTER key to continue");
				getchar();
				getchar();
			} else {
				x = x - 1;	//reduce n-1 positions the array
				flag = passengersPrinter(input, array, x);//if print success, set flag to 1
			}
			rewind(input);		//rewind stream
			fclose(input);		//close file
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Input file, passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersDeleter_Admin(FILE *input, passengers array[], int x) {

	/**
	 * Passengers delete.
	 *
	 * Return:
	 *
	 * [1] if success
	 * [0] if failed
	 */

	int flag = 0, flag1 = 0, flag2 = 0, deleted = 0;
	char username[LEN], passport[LEN], select = 'y';

	getchar();
	printf("Do you want to delete an account? [y/n]: ");
	scanf("%c", &select);
	while (!isalpha(select)) {
		printf("\nInvalid selection."
				"Please, retry: ");
		scanf("%c", &select);
	}

	if (select == 'y') {

		printf("\nInsert username to delete: ");
		scanf("%s", username);		//get username
		while ((strlen(username) < MIN_LEN) || (strlen(username) > MAX_LEN)) {	//control over username
			printf("\n\nInvalid username."
					"\nPlease, insert a valid one: ");
			scanf("%s", username);
		}

		for (int i = 0; i < x; i++) {
			if (strcasecmp(array[i].username, username) == 0) { //check matching
				deleted = i;		//passengers index

				for (int i = deleted; i < x; i++) {	//copy next elements starting by deleted position
					int j = i + 1;
					strcpy(array[i].name, array[j].name);
					strcpy(array[i].surname, array[j].surname);
					strcpy(array[i].username, array[j].username);
					strcpy(array[i].passport_number, array[j].passport_number);
					array[i].birth_date.day = array[j].birth_date.month;
					array[i].birth_date.month = array[j].birth_date.month;
					array[i].birth_date.year = array[j].birth_date.year;
					array[i].signup_date.day = array[j].signup_date.day;
					array[i].signup_date.month = array[j].signup_date.month;
					array[i].signup_date.year = array[j].signup_date.year;
					j++;
					flag2 = 1;		//set flag2 to 1 if delete successful
				}

				flag1 = 1;		//set flag to 1 if success
			}
		}

		flag = flagChecker(flag1, flag2);//if flag1 and flag2 = 1, they'll return 1


			input = fopen("passengers.csv", "w");//open passengers.csv in write mode, deleting the existing content

			if ((input = fopen("passengers.csv", "w")) == NULL) {//check over opening
				printf("\n\nFile passengers.csv not found."
						"\nPress ENTER key to continue");
				getchar();
				getchar();
			} else {
				x = x - 1;	//reduce n-1 positions the array
				flag = passengersPrinter(input, array, x);//if print success, set flag to 1
			}
			rewind(input);		//rewind stream
			fclose(input);		//close file
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersView(passengers array[], int x) {
	int flag = 0;
	for (int i = 0; i < x; i++) {
		printf("%d° passenger."
				"\nName: %s"
				"\nSurname: %s"
				"\nUsername: %s"
				"\nPassport number: %s"
				"\nBirth date: %d-%d-%d"
				"\nSign-up date: %d-%d-%d.\n\n", i, array[i].name,
				array[i].surname, array[i].username, array[i].passport_number,
				array[i].birth_date.day, array[i].birth_date.month,
				array[i].birth_date.year, array[i].signup_date.day,
				array[i].signup_date.month, array[i].signup_date.year);
		flag = 1;		//if print success, set flag to 1
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Input file, passengers and temp arrays and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersCloner(passengers array[], int x, passengers temp[]) {
	int flag = 0;
	for (int i = 0; i < x; i++) {
		temp[i] = array[i];
		flag = 1;		//set flag to 1
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers temporary array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersDecreasingBubbleSort_Signupyear(passengers test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;
	passengers temp;
	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].signup_date.year > test[min_idx].signup_date.year) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;		//set flag to 1
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers temporary array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersDecreasingBubbleSort_Birthyear(passengers test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;
	passengers temp;
	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].birth_date.year > test[min_idx].birth_date.year) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;		//set flag to 1 if success
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers temporary array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersIncreasingBubbleSort_Signupyear(passengers test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;
	passengers temp;
	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].signup_date.year < test[min_idx].signup_date.year) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;		//set flag to 1 if success
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers temporary array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersIncreasingBubbleSort_Birthyear(passengers test[], int x) {
	int i = 0, j = 0, min_idx, flag = 0;
	passengers temp;
	for (i = 0; i < x; i++) {
		min_idx = i;
		for (j = i + 1; j < x; j++) {
			if (test[j].birth_date.year < test[min_idx].birth_date.year) {
				min_idx = j;
			}
		}
		temp = test[min_idx];
		test[min_idx] = test[i];
		test[i] = temp;
		flag = 1;		//set flag to 1 if success
	}
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersSearch_Name(passengers array[], int x) {
	char option = 'y', word[LEN], subsearch = 'y';

	int flag = 0;

	system("clear");

	getchar();
	printf("\n\nDo you want to start a new search by name? [y/n]: ");
	scanf("%c", &option);
	while (!isalpha(option)) {
		printf("\nInvalid selection."
				"Please, retry: ");
		scanf("%c", &option);
	}

	if (option == 'y') {	//start search

		printf("\nInsert name: ");	//get name
		scanf("%s", word);
		while ((strlen(word) < MIN_LEN) || (strlen(word) > MAX_LEN)) {	//control over name
			printf("\nInvalid name."
					"Please, insert a name: ");
			scanf("%s", word);
		}

		for (int i = 0; i < x; i++) {
			if (strcasecmp(array[i].name, word) == 0) {
				printf("\nName: %s"
						"\nSurname: %s"
						"\nUsername: %s"
						"\nPassport number: %s"
						"\nBirth date: %d-%d-%d"
						"\nSignup date: %d-%d-%d\n\n", array[i].name,
						array[i].surname, array[i].username,
						array[i].passport_number, array[i].birth_date.day,
						array[i].birth_date.month, array[i].birth_date.year,
						array[i].signup_date.day, array[i].signup_date.month,
						array[i].signup_date.year);
				flag = 1;
			}
		}

		printf(
				"\n\nSearch completed.\n"
						"Do you want to expand the search with a sub-string search? [y/n]: ");
		getchar();
		scanf("%c", &subsearch);
		while (!isalpha(subsearch)) {
			printf("\nInvalid selection."
					"Please, retry: ");
			scanf("%c", &subsearch);
		}

		if (subsearch == 'y') {

			printf("\nInsert a word to search for: ");	//insert word
			scanf("%s", word);
			while ((strlen(word) < MIN_SUBSEARCH) || (strlen(word) > MAX_LEN)) {	//lenght check
				printf("\nInvalid word."
						"\nPlease insert a valid word: ");
				scanf("%s", word);
			}

			for (int i = 0; i < x; i++) { //sub search for
				if (strstr(array[i].name, word) == NULL) {
					printf("\nNo match results in %d passenger.", i);
				} else {	//if elements are found
					printf("\n\n%d Passenger:"
							"\nName: %s"
							"\nSurname: %s"
							"\nUsername: %s"
							"\nPassport number: %s"
							"\nBirth date: %d-%d-%d"
							"\nSignup date: %d-%d-%d\n\n", i, array[i].name,
							array[i].surname, array[i].username,
							array[i].passport_number, array[i].birth_date.day,
							array[i].birth_date.month, array[i].birth_date.year,
							array[i].signup_date.day,
							array[i].signup_date.month,
							array[i].signup_date.year);
				}	//end elements found
			}	//end sub search
		}	//end subsearch menu
	} //end search
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersSearch_Surname(passengers array[], int x) {
	char option = 'y', word[LEN], subsearch = 'y';

	int flag = 0;

	system("clear");
	getchar();
	printf("\n\nDo you want to start a new search by surname? [y/n]: ");
	scanf("%c", &option);
	while (!isalpha(option)) {
		printf("\nInvalid selection."
				"Please, retry: ");
		scanf("%c", &option);
	}

	if (option == 'y') {	//start search

		printf("\nInsert surname: ");	//get name
		scanf("%s", word);
		while ((strlen(word) < MIN_LEN) || (strlen(word) > MAX_LEN)) {
			printf("\nInvalid surname."
					"Please, insert a surname: ");
			scanf("%s", word);
		}

		for (int i = 0; i < x; i++) {	//start for
			if (strcasecmp(array[i].surname, word) == 0) {	//start strcasecmp
				printf("\nName: %s"
						"\nSurname: %s"
						"\nUsername: %s"
						"\nPassport number: %s"
						"\nBirth date: %d-%d-%d"
						"\nSignup date: %d-%d-%d\n\n", array[i].name,
						array[i].surname, array[i].username,
						array[i].passport_number, array[i].birth_date.day,
						array[i].birth_date.month, array[i].birth_date.year,
						array[i].signup_date.day, array[i].signup_date.month,
						array[i].signup_date.year);
				flag = 1;		//set flag to 1 if success
			}	//end strcasecmp
		}	//end for

		getchar();
		printf(
				"\n\nSearch completed.\n"
						"Do you want to expand the search with a sub-string search? [y/n]: ");
		scanf("%c", &subsearch);
		while (!isalpha(subsearch)) {
			printf("\nInvalid selection."
					"Please, retry: ");
			scanf("%c", &subsearch);
		}

		if (subsearch == 'y') {

			printf("\nInsert a word to search for: ");	//insert word
			scanf("%s", word);
			while ((strlen(word) < MIN_SUBSEARCH) || (strlen(word) > MAX_LEN)) {	//lenght check
				printf("\nInvalid word."
						"\nPlease insert a valid word (min 1 char): ");
				scanf("%s", word);
			}

			for (int i = 0; i < x; i++) { //sub search for
				if (strstr(array[i].surname, word) == NULL) {
					printf("\nNo search results in %d passenger.", i);
				} else {	//if elements are found
					printf("\n\n%d Passenger:"
							"\nName: %s"
							"\nSurname: %s"
							"\nUsername: %s"
							"\nPassport number: %s"
							"\nBirth date: %d-%d-%d"
							"\nSignup date: %d-%d-%d\n\n", i, array[i].name,
							array[i].surname, array[i].username,
							array[i].passport_number, array[i].birth_date.day,
							array[i].birth_date.month, array[i].birth_date.year,
							array[i].signup_date.day,
							array[i].signup_date.month,
							array[i].signup_date.year);
				}	//end elements found
			}	//end sub search
		}	//end subsearch menu
	} //end search
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersSearch_Username(passengers array[], int x) {
	char option = 'y', word[LEN], subsearch = 'y';

	int flag = 0;

	system("clear");
	getchar();
	printf("\n\nDo you want to start a new search by username? [y/n]: ");
	scanf("%c", &option);
	while (!isalpha(option)) {
		printf("\nInvalid selection."
				"Please, retry: ");
		scanf("%c", &option);
	}

	if (option == 'y') {	//start search

		printf("\nInsert username: ");	//get name
		scanf("%s", word);
		while ((strlen(word) < MIN_LEN) || (strlen(word) > MAX_LEN)) {
			printf("\nInvalid username."
					"Please, insert a username: ");
			scanf("%s", word);
		}

		for (int i = 0; i < x; i++) {	//start for
			if (strcasecmp(array[i].username, word) == 0) {	//start strcasecmp
				printf("\nName: %s"
						"\nSurname: %s"
						"\nUsername: %s"
						"\nPassport number: %s"
						"\nBirth date: %d-%d-%d"
						"\nSignup date: %d-%d-%d\n\n", array[i].name,
						array[i].surname, array[i].username,
						array[i].passport_number, array[i].birth_date.day,
						array[i].birth_date.month, array[i].birth_date.year,
						array[i].signup_date.day, array[i].signup_date.month,
						array[i].signup_date.year);
				flag = 1;		//set flag to 1 if success
			}	//end strcasecmp
		}	//end for

		getchar();
		printf(
				"\n\nSearch completed.\n"
						"Do you want to expand the search with a sub-string search? [y/n]: ");
		scanf("%c", &subsearch);
		while (!isalpha(subsearch)) {
			printf("\nInvalid selection."
					"Please, retry: ");
			scanf("%c", &subsearch);
		}

		if (subsearch == 'y') {

			printf("\nInsert a word to search for: ");	//insert word
			scanf("%s", word);
			while ((strlen(word) < MIN_SUBSEARCH) || (strlen(word) > MAX_LEN)) {	//lenght check
				printf("\nInvalid word."
						"\nPlease insert a valid word (min 1 char): ");
				scanf("%s", word);
			}

			for (int i = 0; i < x; i++) { //sub search for
				if (strstr(array[i].username, word) == NULL) {
					printf("\nNo search results in %d passenger.", i);
				} else {	//if elements are found
					printf("\n\n%d Passenger:"
							"\nName: %s"
							"\nSurname: %s"
							"\nUsername: %s"
							"\nPassport number: %s"
							"\nBirth date: %d-%d-%d"
							"\nSignup date: %d-%d-%d\n\n", i, array[i].name,
							array[i].surname, array[i].username,
							array[i].passport_number, array[i].birth_date.day,
							array[i].birth_date.month, array[i].birth_date.year,
							array[i].signup_date.day,
							array[i].signup_date.month,
							array[i].signup_date.year);

				}	//end elements found
			}	//end sub search
		}	//end subsearch menu
	} //end search
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersSearch_BirthYear(passengers array[], int x) {
	char option = 'y';

	int flag = 0, year = 0;

	while (option == 'y') {
		system("clear");
		getchar();
		printf("\n\nDo you want to start a new search by birth year? [y/n]: ");
		scanf("%c", &option);
		while (!isalpha(option)) {
			printf("\nInvalid selection."
					"Please, retry: ");
			scanf("%c", &option);
		}

		if (option == 'y') {	//start search

			printf("\nInsert birth year: ");	//get name
			scanf("%d", &year);
			while ((year < 1920) && (year > 2019)) {	//get year
				printf("\nInvalid year."
						"Please, insert an year: ");
				scanf("%d", &year);
			}

			for (int i = 0; i < x; i++) {	//start for
				if (array[i].birth_date.year == year) {	//start comparison
					printf("\nName: %s"
							"\nSurname: %s"
							"\nUsername: %s"
							"\nPassport number: %s"
							"\nBirth date: %d-%d-%d"
							"\nSignup date: %d-%d-%d\n\n", array[i].name,
							array[i].surname, array[i].username,
							array[i].passport_number, array[i].birth_date.day,
							array[i].birth_date.month, array[i].birth_date.year,
							array[i].signup_date.day,
							array[i].signup_date.month,
							array[i].signup_date.year);
					flag = 1;		//set flag to 1 if match found
				}	//end comparison
			}	//end for
		}	//end if
	}	//end while
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersSearch_SignupYear(passengers array[], int x) {
	char option = 'y';

	int flag = 0, year = 0;

	while (option == 'y') {
		getchar();
		system("clear");
		printf(
				"\n\nDo you want to start a new search by sign-up year? [y/n]: ");
		scanf("%c", &option);
		while (!isalpha(option)) {
			printf("\nInvalid selection."
					"Please, retry: ");
			scanf("%c", &option);
		}

		if (option == 'y') {	//start search

			printf("\nInsert signup year: ");	//get name
			scanf("%d", &year);
			while ((year < 1920) && (year > 2019)) {	//get year
				printf("\nInvalid year."
						"Please, insert an year: ");
				scanf("%d", &year);
			}

			for (int i = 0; i < x; i++) {	//start for
				if (array[i].signup_date.year == year) {	//start comparison
					printf("\nName: %s"
							"\nSurname: %s"
							"\nUsername: %s"
							"\nPassport number: %s"
							"\nBirth date: %d-%d-%d"
							"\nSignup date: %d-%d-%d\n\n", array[i].name,
							array[i].surname, array[i].username,
							array[i].passport_number, array[i].birth_date.day,
							array[i].birth_date.month, array[i].birth_date.year,
							array[i].signup_date.day,
							array[i].signup_date.month,
							array[i].signup_date.year);
					printf("\n\nPassenger found.\n"
							"Press ENTER key to continue.");
					getchar();
					getchar();
					flag = 1;		//set flag to 1 if match found
				}	//end comparison
			}	//end for
		}	//end if
	}	//end while
	return flag;
}

/**
 *Pre-conditions:
 *	Passengers array and dimension must exist.
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
int passengersSearch(passengers array[], int x) {
	int select = 0, flag = 0;

	while (select != 6) {
		system("clear");
		printf("\t\t---Search menu for passengers---"
				"\n\t(1) Search passenger by name;"
				"\n\t(2) Search passenger by surname;"
				"\n\t(3) Search passenger by username;"
				"\n\t(4) Search passenger by birth year;"
				"\n\t(5) Search passenger by signup year;"
				"\n\t(6) Return."
				"\n\nSelect an option [1-6]: ");
		scanf("%d", &select);

		switch (select) {
		case 1:
			flag = passengersSearch_Name(array, x);
			flagMessage(flag);
			break;
		case 2:
			flag = passengersSearch_Surname(array, x);
			flagMessage(flag);
			break;
		case 3:
			flag = passengersSearch_Username(array, x);
			flagMessage(flag);
			break;
		case 4:
			flag = passengersSearch_BirthYear(array, x);
			flagMessage(flag);
			break;
		case 5:
			flag = passengersSearch_SignupYear(array, x);
			flagMessage(flag);
			break;
		case 6:	//exit case to prevent the exit clause wrong recoinnaised by the default case
			system("clear");
			printf("Returning...\n\n");
			break;
		default://defensive prog. against non-admitted chars, wrong selection, and symbols
			system("clear");
			getchar();
			printf("\n\nWrong selection."
					"\nPress ENTER key to retry.");
			getchar();
			getchar();
			break;
		}

	}
	return flag;
}

/**
 *Pre-conditions:
 *	Input pointer to file, sassengers array and dimension must exist.
 *
 *
 *Post-conditions:
 * 	 If operation is successful, return value will be 1,
 * 	 else 0.
 *
 */
void passengersSortingMenu(void) {
	int menu = 0, n = 0, flagLoad = 0, flagCheck = 0, flag1 = 0, flagVerify = 0,
			flagView = 0;

	FILE *passengersPtr;		//pointer to file

	while (menu != 5) {

		fflush(stdin);
		fflush(stdout);

		menu = 0;	//re-set menu to 0

		passengersPtr = fopen("passengers.csv", "r");//point to passengers.csv - read mode

		n = rowCount(passengersPtr, "passengers.csv");	//get passengers number

		passengers passenger[n], sorted[n];		//n-dimension array

		if ((passengersPtr = fopen("passengers.csv", "r")) == NULL) {//control over file open
			system("clear");
			printf("File not found."
					"\nPress ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flagLoad = passengersLoad(passengersPtr, passenger, n);	//1 if load success
			flagCheck = passengersCloner(passenger, n, sorted);	//1 if cloning success
			flagVerify = flagChecker(flagLoad, flagCheck);	//1 if 1 and 1
			system("clear");
			printf("\t\t---Sorting Menu---\n"
					"\n\t(1) Increasing sort passengers by birth year;"
					"\n\t(2) Decreasing sort passengers by birth year;"
					"\n\t(3) Increasing sort passengers by signup date;"
					"\n\t(4) Decreasing sort passengers by signup date;"
					"\n\t(5) Return. "
					"\n\nSelect an option [1-5]: ");
			scanf("%d", &menu);

			switch (menu) {
			case 1:
				flag1 = (sorted, n);//1 if success
				flagVerify = flagChecker(flagVerify, flag1);	//1 if 1 and 1
				flagView = passengersView(sorted, n);//1 if display successful
				flagVerify = flagChecker(flagVerify, flagView);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 2:
				flag1 = passengersDecreasingBubbleSort_Birthyear(sorted, n);//1 if success
				flagVerify = flagChecker(flagVerify, flag1);	//1 if 1 and 1
				flagView = passengersView(sorted, n);//1 if display successful
				flagVerify = flagChecker(flagVerify, flagView);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 3:
				flag1 = passengersIncreasingBubbleSort_Signupyear(sorted, n);//1 if success
				flagVerify = flagChecker(flagVerify, flag1);	//1 if 1 and 1
				flagView = passengersView(sorted, n);//1 if display successful
				flagVerify = flagChecker(flagVerify, flagView);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 4:
				flag1 = passengersDecreasingBubbleSort_Signupyear(sorted, n);//1 if success
				flagVerify = flagChecker(flagVerify, flag1);	//1 if 1 and 1
				flagView = passengersView(sorted, n);//1 if display successful
				flagVerify = flagChecker(flagVerify, flagView);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 5:	//exit case to prevent the exit clause wrong recoinnaised by the default case
				system("clear");
				printf("Returning...\n\n");
				break;
			default://defensive prog. against non-admitted chars, wrong selection, and symbols
				system("clear");
				getchar();
				printf("\n\nWrong selection."
						"\nPress ENTER key to retry.");
				getchar();
				getchar();
				break;
			}

		}
	}
}

/**
 * Pre-conditions:
 * 	File passengers.csv must exist.
 *
 * Post-conditions:
 * 	Basing over the requested action, the file
 * 	passengers.csv will be updated with new, edited or
 * 	deleted rows containing passengers data.
 */
void administratorMenu(void) {
	int menu = 0, flagLoad = 0, n = 0, flag1 = 0, flagVerify = 0;

	FILE *passengersPtr;	//pointer to file

	while (menu != 6) {

		fflush(stdin);
		fflush(stdout);

		menu = 0;		//re-set menu to 0

		passengersPtr = fopen("passengers.csv", "r");//point to passengers.csv - read mode

		n = rowCount(passengersPtr, "passengers.csv");	//get passengers number

		passengers passenger[n];	//n-dimension array

		if ((passengersPtr = fopen("passengers.csv", "r")) == NULL) {//check over file opening
			system("clear");
			printf("\n\nFile passengers.csv not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flagLoad = passengersLoad(passengersPtr, passenger, n);	//1 if load success

			system("clear");

			printf("\t\t---Administrator menù---\n\n"
					"(1) Add a passenger;"
					"\n(2) Edit a passenger;"
					"\n(3) Delete a passenger;"
					"\n(4) Sorting menù;"
					"\n(5) Access passenger search menu;"
					"\n(6) Return."
					"\n\nSelect an option[1-6]: ");
			scanf("%d", &menu);

			switch (menu) {
			case 1:
				flag1 = passengersAdd(passengersPtr);	//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 2:
				flag1 = passengersEditor_Admin(passengersPtr, passenger, n);//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 3:
				flag1 = passengersDeleter_Admin(passengersPtr, passenger, n);//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 4:
				passengersSortingMenu();		//go to passengers sorting
				break;
			case 5:
				flag1 = passengersSearch(passenger, n);	//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 6:	//exit case to prevent the exit clause wrong recoinnaised by the default case
				system("clear");
				printf("Returning...\n\n");
				break;
			default://defensive prog. against non-admitted chars, wrong selection, and symbols
				system("clear");
				getchar();
				printf("\n\nWrong selection."
						"\nPress ENTER key to retry.");
				getchar();
				getchar();
				break;
			}
		}

	}
}

/**
 * Pre-conditions:
 * 	File passengers.csv must exist.
 *
 * Post-conditions:
 * 	Basing over the requested action, the file
 * 	passengers.csv will be updated with new, edited or
 * 	deleted rows containing passengers data.
 */
void passengersMenu(void) {
	int menu = 0, flagLoad = 0, n = 0, flag1 = 0, flagVerify = 0;

	FILE *passengersPtr;	//pointer to file passengers.csv

	while (menu != 5) {

		fflush(stdin);
		fflush(stdout);

		menu = 0;	//re-set menu to 0

		passengersPtr = fopen("passengers.csv", "r");	//open in read mode

		n = rowCount(passengersPtr, "passengers.csv");//take the number of rows from file

		passengers passenger[n];	//passenger n-dimension array

		if ((passengersPtr = fopen("passengers.csv", "r")) == NULL) {//control over open
			system("clear");
			printf("File not found.\n"
					"Press ENTER key to continue.");
			getchar();
			getchar();
		} else {
			flagLoad = passengersLoad(passengersPtr, passenger, n);	//load data into passenger array, 1 if success

			system("clear");

			printf("\t\t---User menu---\n\n"
					"(1) Sign-Up;"
					"\n(2) Edit your account;"
					"\n(3) Delete your account;"
					"\n(4) Bookings menù."
					"\n(5) Return.\n"
					"\n\nSelect an option[1-5]: ");
			scanf("%d", &menu);

			switch (menu) {
			case 1:
				flag1 = passengersAdd(passengersPtr);	//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;

			case 2:
				flag1 = passengersEditor(passengersPtr, passenger, n);//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 3:
				flag1 = passengersDeleter(passengersPtr, passenger, n);	//1 if success
				flagVerify = flagChecker(flagLoad, flag1);	//1 if 1 and 1
				flagMessage(flagVerify);	//output message based on flagVerify
				break;
			case 4:
				bookingsMenu_User();
				break;
			case 5:	//exit case to prevent the exit clause wrong recoinnaised by the default case
				system("clear");
				printf("Returning...\n\n");
				break;
			default://defensive prog. against non-admitted chars, wrong selection, and symbols
				system("clear");
				getchar();
				printf("\n\nWrong selection."
						"\nPress ENTER key to retry.");
				getchar();
				getchar();
				break;
			}
		}
	}
}
