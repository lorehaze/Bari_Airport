/**
 *
 * @file utility.h
 *
 * In this header file, are stored prototypes
 * to functions and methods that are generic called into
 * the project.
 *
 * Those functions guarantees the check over
 * 	flags, then output a message based on
 * 	the return value.
 *
 * 	@version 1
 * 	@date 08/06/2019
 * 	@authors Lorenzo Baldari
 * 	@copyright GNU GPL
 *
 */

#ifndef SRC_UTILITY_H_
#define SRC_UTILITY_H_

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 * Print a message, based on the input.
 *
 * @param x opening flag
 */
void flagMessage(int x);

/**
 *
 * Count lines per file.
 * 	Store the value in count.
 * 		Return count.
 *
 * @param input	Pointer to file.
 * @param file_name File name to read.
 * @return	count Number of rows in file.
 *
 */
int rowCount(FILE *input, char *file_name);

/**
 *
 * x AND y
 *
 * @param x Get first flag
 * @param y	Get second flag
 * @return	flag flag1 AND flag2
 */
int flagChecker(int x, int y);

#endif /* SRC_UTILITY_H_ */
