/**
 *
 * @file bookings.h
 *
 * In this header file are stored all the methods
 * and functions related to bookings.
 *
 * Those functions guarantee all the operations provided
 * for bookings.
 * Several call to functions and methods contained in
 * utility.h are also contained.
 *
 * 	@version 1
 * 	@date 08/06/2019
 * 	@authors Lorenzo Baldari
 * 	@copyright GNU GPL
 *
 */

#ifndef BOOKINGS_H_
#define BOOKINGS_H_

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <CUnit/Automated.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Console.h>

/**
 * Max admissible value for string lenght.
 */
#define LEN 20

/**
 * Max admissible  value for passport ID.
 */
#define PASSPORT 10

/**
 * Max and min admissible value for
 * string lenght.
 * Used by defensive programmation scopes.
 */
#define MAX_LEN 19
#define MIN_LEN 3

/**
 * Structure defined to contain all the bookings data
 * defined by fields.
 */
typedef struct bookings {
	char booking_id[LEN], username[LEN], fly_id[LEN], departure[LEN],
			arrival[LEN];
	int check_in, boarded;
} bookings;

int flagChecker(int x, int y);	//check flag: flag AND flag
int flightsLoad(FILE *input, flights array[], int x);	//load flights
int passengersLoad(FILE *input, passengers array[], int x);	//load passengers
void flagMessage(int x);	//output message based on int value
int rowCount(FILE *input, char *file_name);	//count rows in a file

/**
 * This method will clean a bookings array.
 *
 * @param array Bokings array
 * @param b_dim	Array dimension.
 */
void bookingsCleaner(bookings array[], int b_dim);		//clean bookings array

/**
* This method will print to display
 * all the passengers which hasn't boarded.
 *
 * @param b_array Bookings array
 * @param b_dim	Array dimension
 */
void nonboarded(bookings b_array[], int b_dim);	//show non boarded passengers

/**
 * This function will load all the bookings data
 * contained in bookings.csv into the bookings
 * array.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input	Pointer to bookings.csv
 * @param array	Bookings array
 * @param x	Array dimension
 * @return flag 1 if success, else 0
 */
int bookingsLoad(FILE *input, bookings array[], int x);	//load data into array

/**
 * This function will print all the bookings data
 * contained in the array into the file bookings.csv.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input	Pointer to bookings.csv
 * @param array	Bookings array
 * @param x	Array dimension
 * @return flag 1 if success, else 0
 */
int bookingsPrinter(FILE *input, bookings array[], int x);//print data into file

/**
 * This function will add a booking by user-side.
 * The user have to insert all the bookings information.
 * The operation will start after a login with
 * username ad passport ID.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param p_array	Passengers array
 * @param p_dim	Passengers array dimension
 * @param f_array	Flights array
 * @param f_dim	Flights array dimension
 * @return	flag 1 if success, 0 else
 */
int bookingsAdd_User(FILE *input, passengers p_array[], int p_dim,//add an user
		flights f_array[], int f_dim);

/**
 *
 * This function edit a bookings, then print the
 * newest updated array into the bookings.csv file.
 * The operation will start after a login with
 * username ad passport ID.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim	Bookings array dimension
 * @param f_array	Flights array
 * @param f_dim	Flights array dimension
 * @param p_array	Passengers array
 * @param p_dim	Passengers array dimension
 * @return	flag 1 if success, else 0
 */
int bookingsEdit(FILE *input, bookings b_array[], int b_dim, flights f_array[],	//edit user data
		int f_dim, passengers p_array[], int p_dim);

/**
 *
 * This function delete a booking, then print the
 * newest updated array into the bookings.csv file.
 * The operation will start after a login with
 * username ad passport ID.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim	Array dimension
 * @return flag 1 if success, else 0
 */
int bookingsDelete(FILE *input, bookings b_array[], int b_dim);	//delete account

/**
 *
 * This functions will permit the check-in, then
 * update the booking.csv file.
 * The operation will start after a login with
 * username ad booking ID.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim	Bookings array dimension
 * @param f_array	Flights array
 * @param f_dim	Flights array dimension
 * @return flag 1 if success, else 0
 */
int checkIn(FILE *input, bookings b_array[], int b_dim, flights f_array[],
		int f_dim);		//do the check in

/**
 *
 * This method will permit the boarding of a passenger.
 * The operation will start after a login with
 * username ad booking ID.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 *
 * @param input	Pointer to bookings.csv
 * @param p_array	Passengers array
 * @param p_dim	Passengers array dimension
 * @param b_array	Bookings array
 * @param b_dim	Bookings array dimension
 * @param offset	Offset value
 */
void boarding(FILE *input, passengers p_array[], int p_dim, bookings b_array[],
		int b_dim, long int *offset);	//boarding method

/**
 * This method will show the user a menu, in which
 * are listed all the available options.
 */
void bookingsMenu_User(void);		//bookings user menu

/**
 *
 * This function will add a booking by admin-side.
 * The admin have to insert all the bookings information.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim		Bookings array dimension
 * @param p_array	Passengers array
 * @param p_dim	Passengers array dimension
 * @param f_array	Flights array
 * @param f_dim	Flights array dimension
 * @return flag 1 if success, else 0
 */
int bookingsAdd_Admin(FILE *input, bookings b_array[], int b_dim,//bookings menu admin
		passengers p_array[], int p_dim, flights f_array[], int f_dim);

/**
 *
 * This function will edit a booking by admin-side.
 * The admin have to insert all the bookings information.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim		Bookings array dimension
 * @param p_array	Passengers array
 * @param p_dim	Passengers array dimension
 * @param f_array	Flights array
 * @param f_dim	Flights array dimension
 * @return flag 1 if success, else 0
 */
int bookingsEdit_Admin(FILE *input, bookings b_array[], int b_dim,//edit as admin
		flights f_array[], int f_dim, passengers p_array[], int p_dim);

/**
 *
 * This function will delete a booking by admin-side.
 * The admin have to insert the booking number.
 * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim		Bookings array dimension
 * @return flag 1 if success, else 0
 */
int bookingsDelete_Admin(FILE *input, bookings b_array[], int b_dim);//delete as admin

/**
 *
 * This function will search a booking
 * by username.
  * In the final stage, flag will be set to 1
 * in case of success.
 *
 * @param input Pointer to bookings.csv
 * @param b_array	Bookings array
 * @param b_dim		Bookings array dimension
 * @return flag 1 if success, else 0
 */
int bookingsSearch_Username(FILE *input, bookings b_array[], int b_dim);//search booking by username

/**
 * This method will show the search menu
 * in which are listed all the search
 * options.
 */
void bookingsSearch_Menu(void);		//search menu

/**
 * This method will show the administrator menu
 * related to bookings.
 */
void bookingsMenu_Admin(void);		//admin booking menu

#endif /* BOOKINGS_H_ */
